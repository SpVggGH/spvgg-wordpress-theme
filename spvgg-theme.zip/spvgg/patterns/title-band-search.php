<?php
/**
 * Title: Titel-Band: Suche
 * Slug: spvgg/title-band-search
 * Categories: spvgg
 * Inserter: no
 * Description: Suchergebnis-Titel und Suchfeld auf Hero-Foto-Ausschnitt.
 */

// phpcs:ignore WordPress.Security.EscapeOutput -- Block-Markup aus Theme-Funktionen, Texte dort escaped
echo spvgg_title_band(
	spvgg_title_kicker( 'Suche' ) . '
		<!-- wp:query-title {"type":"search","className":"spvgg-title-band__title","textColor":"weiss"} /-->
		<!-- wp:search {"label":"Suche","showLabel":false,"placeholder":"Suchbegriff","buttonText":"Suchen","className":"spvgg-title-band__search"} /-->'
);
