<?php
/**
 * Title: Titel-Band: News
 * Slug: spvgg/title-band-news
 * Categories: spvgg
 * Inserter: no
 * Description: Titel der News-Seite auf Hero-Foto-Ausschnitt.
 */

// phpcs:ignore WordPress.Security.EscapeOutput -- Block-Markup aus Theme-Funktionen, Texte dort escaped
echo spvgg_title_band(
	spvgg_title_kicker( 'Aktuelles aus dem Verein' ) . '
		<!-- wp:post-title {"level":1,"className":"spvgg-title-band__title","textColor":"weiss"} /-->'
);
