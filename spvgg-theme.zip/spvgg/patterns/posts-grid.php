<?php
/**
 * Title: News-Raster
 * Slug: spvgg/posts-grid
 * Categories: spvgg, query
 * Inserter: no
 * Description: Beitragsraster (3 Spalten) mit Bild, Kategorie, Datum und Auszug – erbt die aktuelle Abfrage.
 */
?>
<!-- wp:query {"queryId":1,"query":{"perPage":9,"pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","inherit":true},"align":"wide"} -->
<div class="wp-block-query alignwide">
	<!-- wp:post-template {"className":"spvgg-posts","layout":{"type":"grid","columnCount":3,"minimumColumnWidth":"18rem"}} -->
		<?php echo spvgg_post_card(); // phpcs:ignore WordPress.Security.EscapeOutput -- statisches Block-Markup ?>
	<!-- /wp:post-template -->

	<!-- wp:query-pagination {"paginationArrow":"none","layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|50"}}}} -->
		<!-- wp:query-pagination-previous {"label":"Neuere Beiträge"} /-->
		<!-- wp:query-pagination-numbers /-->
		<!-- wp:query-pagination-next {"label":"Ältere Beiträge"} /-->
	<!-- /wp:query-pagination -->

	<!-- wp:query-no-results -->
		<!-- wp:paragraph -->
		<p>Hier gibt es noch keine Beiträge.</p>
		<!-- /wp:paragraph -->
	<!-- /wp:query-no-results -->
</div>
<!-- /wp:query -->
