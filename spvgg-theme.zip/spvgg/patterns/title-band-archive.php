<?php
/**
 * Title: Titel-Band: Kategorie/Archiv
 * Slug: spvgg/title-band-archive
 * Categories: spvgg
 * Inserter: no
 * Description: Name der Kategorie (bzw. des Archivs) und Beschreibung auf Hero-Foto-Ausschnitt.
 */

// phpcs:ignore WordPress.Security.EscapeOutput -- Block-Markup aus Theme-Funktionen, Texte dort escaped
echo spvgg_title_band(
	spvgg_title_kicker( is_category() ? 'Kategorie' : 'Archiv' ) . '
		<!-- wp:query-title {"type":"archive","showPrefix":false,"className":"spvgg-title-band__title","textColor":"weiss"} /-->
		<!-- wp:term-description {"className":"spvgg-title-band__text","textColor":"weiss"} /-->'
);
