<?php
/**
 * Title: Abteilung: News
 * Slug: spvgg/dept-news
 * Categories: spvgg
 * Inserter: no
 * Description: Neueste Beiträge der Abteilungs-Kategorie und Button zu allen News der Abteilung.
 */
?>
<!-- wp:group {"className":"spvgg-dept-news","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"},"margin":{"top":"0"}}},"backgroundColor":"hellgrau","layout":{"type":"constrained"}} -->
<div class="wp-block-group spvgg-dept-news has-hellgrau-background-color has-background" style="margin-top:0;padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">
	<!-- wp:group {"align":"wide","className":"spvgg-section-head","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
	<div class="wp-block-group alignwide spvgg-section-head">
		<!-- wp:heading -->
		<h2 class="wp-block-heading">News aus der Abteilung</h2>
		<!-- /wp:heading -->
	</div>
	<!-- /wp:group -->

	<!-- wp:query {"queryId":64,"query":{"perPage":<?php echo (int) spvgg_front_posts(); ?>,"pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","inherit":false},"align":"wide"} -->
	<div class="wp-block-query alignwide">
		<!-- wp:post-template {"className":"spvgg-posts","layout":{"type":"grid","columnCount":3,"minimumColumnWidth":"18rem"}} -->
			<?php echo spvgg_post_card(); // phpcs:ignore WordPress.Security.EscapeOutput -- statisches Block-Markup ?>
		<!-- /wp:post-template -->

		<!-- wp:query-no-results -->
			<!-- wp:paragraph -->
			<p>In dieser Abteilung gibt es noch keine Beiträge.</p>
			<!-- /wp:paragraph -->
		<!-- /wp:query-no-results -->
	</div>
	<!-- /wp:query -->

	<!-- wp:buttons {"align":"wide","layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|50"}}}} -->
	<div class="wp-block-buttons alignwide" style="margin-top:var(--wp--preset--spacing--50)">
		<!-- wp:button {"className":"spvgg-news-link spvgg-dept-news-link"} -->
		<div class="wp-block-button spvgg-news-link spvgg-dept-news-link"><a class="wp-block-button__link wp-element-button" href="#">Alle News der Abteilung</a></div>
		<!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
