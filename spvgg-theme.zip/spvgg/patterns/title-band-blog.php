<?php
/**
 * Title: Titel-Band: Beitragsübersicht
 * Slug: spvgg/title-band-blog
 * Categories: spvgg
 * Inserter: no
 * Description: Titel „News“ für die WordPress-Beitragsübersicht auf Hero-Foto-Ausschnitt.
 */

// phpcs:ignore WordPress.Security.EscapeOutput -- Block-Markup aus Theme-Funktionen, Texte dort escaped
echo spvgg_title_band(
	spvgg_title_kicker( 'Aktuelles aus dem Verein' ) . '
		<!-- wp:heading {"level":1,"className":"spvgg-title-band__title","textColor":"weiss"} -->
		<h1 class="wp-block-heading spvgg-title-band__title has-weiss-color has-text-color">News</h1>
		<!-- /wp:heading -->'
);
