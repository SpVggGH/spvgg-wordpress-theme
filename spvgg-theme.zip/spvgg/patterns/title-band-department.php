<?php
/**
 * Title: Titel-Band: Abteilung
 * Slug: spvgg/title-band-department
 * Categories: spvgg
 * Inserter: no
 * Description: Name der Abteilung auf Hero-Foto-Ausschnitt.
 */

// phpcs:ignore WordPress.Security.EscapeOutput -- Block-Markup aus Theme-Funktionen, Texte dort escaped
echo spvgg_title_band(
	spvgg_title_kicker( 'Abteilung' ) . '
		<!-- wp:post-title {"level":1,"className":"spvgg-title-band__title","textColor":"weiss"} /-->'
);
