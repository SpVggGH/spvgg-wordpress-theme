<?php
/**
 * Title: Spiele (BFV)
 * Slug: spvgg/matches
 * Categories: spvgg
 * Keywords: spielplan, ergebnisse, bfv, fußball
 * Description: Abgedunkeltes Foto mit nächstem Spiel und letztem Ergebnis je Mannschaft, automatisch vom BFV. Bild und Abdunklung lassen sich im Editor ändern.
 */

$spvgg_bg = esc_url( get_theme_file_uri( 'assets/images/hero.jpg' ) );
?>
<!-- wp:cover {"url":"<?php echo $spvgg_bg; // phpcs:ignore WordPress.Security.EscapeOutput -- oben escaped ?>","dimRatio":60,"overlayColor":"schwarz","focalPoint":{"x":0.62,"y":0.3},"isDark":true,"align":"full","className":"spvgg-matches-section","style":{"spacing":{"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-cover alignfull is-dark spvgg-matches-section" style="margin-top:0;margin-bottom:0"><img class="wp-block-cover__image-background" alt="" src="<?php echo $spvgg_bg; // phpcs:ignore WordPress.Security.EscapeOutput -- oben escaped ?>" style="object-position:62% 30%" data-object-fit="cover" data-object-position="62% 30%"/><span aria-hidden="true" class="wp-block-cover__background has-schwarz-background-color has-background-dim-60 has-background-dim"></span><div class="wp-block-cover__inner-container">
	<!-- wp:spvgg/matches {"align":"wide"} /-->
</div></div>
<!-- /wp:cover -->
