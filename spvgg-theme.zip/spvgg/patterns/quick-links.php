<?php
/**
 * Title: Schnellzugriffe
 * Slug: spvgg/quick-links
 * Categories: spvgg, call-to-action
 * Keywords: links, kacheln, schnellzugriff
 * Description: Vier Link-Kacheln für die wichtigsten Seiten.
 */

$spvgg_links = array(
	array( 'Mitglied werden', 'Beitrittserklärung, Beiträge und alle Infos zur Mitgliedschaft.', '/verein/mitglied-werden/' ),
	array( 'Abteilungen', 'Vom Fußball bis Steeldart – finde deine Sportart.', '/abteilungen/' ),
	array( 'Veranstaltungen', 'Turniere, Feste und Ausflüge im Überblick.', '/veranstaltungen/' ),
	array( 'Hallenbelegung', 'Kursplan und Trainingszeiten in der Halle (PDF).', '/wp-content/uploads/2025/11/251028_Kursplan-TSV-SpVgg-2.pdf' ),
);
?>
<!-- wp:group {"align":"full","className":"spvgg-quicklinks","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"},"margin":{"top":"0"}}},"backgroundColor":"gelb","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull spvgg-quicklinks has-gelb-background-color has-background" style="margin-top:0;padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)">
	<!-- wp:group {"align":"wide","layout":{"type":"grid","columnCount":4,"minimumColumnWidth":"14rem"}} -->
	<div class="wp-block-group alignwide">
	<?php foreach ( $spvgg_links as $spvgg_link ) : ?>
		<!-- wp:group {"className":"spvgg-tile","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"blockGap":"0.5rem"}},"backgroundColor":"schwarz","textColor":"weiss","layout":{"type":"default"}} -->
		<div class="wp-block-group spvgg-tile has-weiss-color has-schwarz-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)">
			<!-- wp:heading {"level":3,"style":{"elements":{"link":{"color":{"text":"var:preset|color|weiss"}}}},"textColor":"weiss","fontSize":"large"} -->
			<h3 class="wp-block-heading has-weiss-color has-text-color has-link-color has-large-font-size"><a href="<?php echo esc_url( $spvgg_link[2] ); ?>"><?php echo esc_html( $spvgg_link[0] ); ?></a></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"style":{"color":{"text":"#c9c9c9"}},"fontSize":"small"} -->
			<p class="has-text-color has-small-font-size" style="color:#c9c9c9"><?php echo esc_html( $spvgg_link[1] ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->
	<?php endforeach; ?>
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
