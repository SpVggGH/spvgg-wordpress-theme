<?php
/**
 * Title: Social Media
 * Slug: spvgg/social
 * Categories: spvgg
 * Keywords: social, whatsapp, facebook, instagram, folgen
 * Description: Leiste „Folge uns auf Social Media“ auf körnigem Flutlicht-Hintergrund mit großen Icons (WhatsApp, Facebook, Instagram – weitere Netzwerke im Editor ergänzbar).
 */
?>
<?php $spvgg_social_bg = esc_url( get_theme_file_uri( 'assets/images/social-bg.jpg' ) ); ?>
<!-- wp:cover {"url":"<?php echo $spvgg_social_bg; ?>","dimRatio":30,"overlayColor":"anthrazit","isDark":true,"align":"full","className":"spvgg-social","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"},"margin":{"top":"0","bottom":"0"},"blockGap":"var:preset|spacing|50"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-cover alignfull is-dark spvgg-social" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><img class="wp-block-cover__image-background" alt="" src="<?php echo $spvgg_social_bg; ?>" data-object-fit="cover"/><span aria-hidden="true" class="wp-block-cover__background has-anthrazit-background-color has-background-dim-30 has-background-dim"></span><div class="wp-block-cover__inner-container">
	<!-- wp:paragraph {"align":"center","className":"spvgg-social__title","fontSize":"large"} -->
	<p class="has-text-align-center spvgg-social__title has-large-font-size">Folge uns auf Social Media</p>
	<!-- /wp:paragraph -->

	<!-- wp:social-links {"iconColor":"weiss","iconColorValue":"#FFFFFF","openInNewTab":true,"size":"has-huge-icon-size","className":"is-style-logos-only spvgg-social__icons","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}},"layout":{"type":"flex","justifyContent":"center"}} -->
	<ul class="wp-block-social-links has-huge-icon-size has-icon-color is-style-logos-only spvgg-social__icons">
		<!-- wp:social-link {"url":"#","service":"whatsapp","label":"WhatsApp"} /-->
		<!-- wp:social-link {"url":"#","service":"facebook","label":"Facebook"} /-->
		<!-- wp:social-link {"url":"#","service":"instagram","label":"Instagram"} /-->
	</ul>
	<!-- /wp:social-links -->
</div></div>
<!-- /wp:cover -->
