<?php
/**
 * Title: Titel-Band: Beitrag
 * Slug: spvgg/title-band-single
 * Categories: spvgg
 * Inserter: no
 * Description: Kategorie, Datum und Beitragstitel auf Hero-Foto-Ausschnitt.
 */

// phpcs:ignore WordPress.Security.EscapeOutput -- Block-Markup aus Theme-Funktionen, Texte dort escaped
echo spvgg_title_band(
	'<!-- wp:group {"className":"spvgg-card-meta spvgg-title-band__meta","style":{"spacing":{"blockGap":"0.75rem"}},"layout":{"type":"flex","flexWrap":"wrap"}} -->
		<div class="wp-block-group spvgg-card-meta spvgg-title-band__meta">
			<!-- wp:post-terms {"term":"category","className":"spvgg-badge"} /-->
			<!-- wp:post-date {"format":"j. F Y"} /-->
		</div>
		<!-- /wp:group -->
		<!-- wp:post-title {"level":1,"className":"spvgg-title-band__title","textColor":"weiss"} /-->'
);
