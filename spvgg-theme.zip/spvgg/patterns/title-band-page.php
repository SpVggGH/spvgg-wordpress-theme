<?php
/**
 * Title: Titel-Band: Seite
 * Slug: spvgg/title-band-page
 * Categories: spvgg
 * Inserter: no
 * Description: Seitentitel auf Hero-Foto-Ausschnitt.
 */

// phpcs:ignore WordPress.Security.EscapeOutput -- Block-Markup aus Theme-Funktionen, Texte dort escaped
echo spvgg_title_band(
	spvgg_title_kicker( 'SpVgg Lagerlechfeld-Graben' ) . '
		<!-- wp:post-title {"level":1,"className":"spvgg-title-band__title","textColor":"weiss"} /-->'
);
