<?php
/**
 * Title: Abteilung: Kacheln der Unterseiten
 * Slug: spvgg/dept-tiles
 * Categories: spvgg
 * Inserter: no
 * Description: Eine Schaltfläche je Unterseite der Abteilung (z. B. Mannschaften) – automatisch, Reihenfolge über die Seiten-Attribute. Stil „Kompakt (Chips)“; ohne Stil wird es ein Slider.
 */
?>
<!-- wp:group {"align":"full","className":"spvgg-quicklinks spvgg-dept-tiles is-style-spvgg-chips","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"},"margin":{"top":"0"}}},"backgroundColor":"gelb","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull spvgg-quicklinks spvgg-dept-tiles is-style-spvgg-chips has-gelb-background-color has-background" style="margin-top:0;padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)">
	<!-- wp:query {"queryId":63,"query":{"perPage":50,"pages":0,"offset":0,"postType":"page","order":"asc","orderBy":"menu_order","inherit":false},"align":"wide"} -->
	<div class="wp-block-query alignwide">
		<!-- wp:post-template {"className":"spvgg-dept-tiles__grid","layout":{"type":"grid","columnCount":4,"minimumColumnWidth":"14rem"}} -->
			<!-- wp:group {"className":"spvgg-tile","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"}}},"backgroundColor":"schwarz","textColor":"weiss","layout":{"type":"default"}} -->
			<div class="wp-block-group spvgg-tile has-weiss-color has-schwarz-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)">
				<!-- wp:post-title {"level":3,"isLink":true,"className":"spvgg-dept-tile__title","style":{"elements":{"link":{"color":{"text":"var:preset|color|weiss"}}}},"textColor":"weiss","fontSize":"large"} /-->
			</div>
			<!-- /wp:group -->
		<!-- /wp:post-template -->
	</div>
	<!-- /wp:query -->
</div>
<!-- /wp:group -->
