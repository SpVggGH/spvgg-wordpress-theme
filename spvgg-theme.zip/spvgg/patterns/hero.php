<?php
/**
 * Title: Hero-Banner
 * Slug: spvgg/hero
 * Categories: spvgg, banner
 * Keywords: hero, banner, startseite
 * Description: Großer Banner mit Flutlicht-Foto, Vereinsname und zwei Buttons.
 */

$spvgg_hero = esc_url( get_theme_file_uri( 'assets/images/hero.jpg' ) );
?>
<!-- wp:cover {"url":"<?php echo $spvgg_hero; ?>","dimRatio":100,"customGradient":"linear-gradient(180deg,rgba(11,11,11,0) 40%,rgba(11,11,11,0.92) 100%)","focalPoint":{"x":0.55,"y":0.4},"minHeight":86,"minHeightUnit":"vh","contentPosition":"bottom left","isDark":true,"align":"full","className":"spvgg-hero","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"},"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-cover alignfull is-dark has-custom-content-position is-position-bottom-left spvgg-hero" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60);min-height:86vh"><img class="wp-block-cover__image-background" alt="" src="<?php echo $spvgg_hero; ?>" style="object-position:55% 40%" data-object-fit="cover" data-object-position="55% 40%"/><span aria-hidden="true" class="wp-block-cover__background has-background-dim-100 has-background-dim wp-block-cover__gradient-background has-background-gradient" style="background:linear-gradient(180deg,rgba(11,11,11,0) 40%,rgba(11,11,11,0.92) 100%)"></span><div class="wp-block-cover__inner-container">
	<!-- wp:group {"align":"wide","layout":{"type":"constrained","contentSize":"820px","justifyContent":"left"}} -->
	<div class="wp-block-group alignwide">
		<!-- wp:paragraph {"className":"spvgg-kicker","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.25em","fontWeight":"700"}},"textColor":"gelb","fontSize":"small"} -->
		<p class="spvgg-kicker has-gelb-color has-text-color has-small-font-size" style="font-weight:700;letter-spacing:0.25em;text-transform:uppercase">Seit 1948 · Sieben Abteilungen</p>
		<!-- /wp:paragraph -->

		<!-- wp:heading {"level":1,"style":{"typography":{"fontSize":"clamp(1.5rem, calc((100vw - 2 * clamp(1.25rem, 5vw, 3.5rem) - 1.5rem) / 10.6), 4.75rem)","lineHeight":"0.95"}},"textColor":"weiss"} -->
		<h1 class="wp-block-heading has-weiss-color has-text-color" style="font-size:clamp(1.5rem, calc((100vw - 2 * clamp(1.25rem, 5vw, 3.5rem) - 1.5rem) / 10.6), 4.75rem);line-height:0.95">SpVgg<br>Lagerlechfeld-Graben</h1>
		<!-- /wp:heading -->

		<!-- wp:paragraph {"style":{"typography":{"fontSize":"1.2rem"}},"textColor":"weiss"} -->
		<p class="has-weiss-color has-text-color" style="font-size:1.2rem">Fußball, Gymnastik &amp; Fitness, Tennis, Ski &amp; Berg, Stockschießen, Tischtennis und Steeldart – ein Verein, eine Gemeinschaft.</p>
		<!-- /wp:paragraph -->

		<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} -->
		<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--40)">
			<!-- wp:button -->
			<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/verein/mitglied-werden/">Mitglied werden</a></div>
			<!-- /wp:button -->
			<!-- wp:button {"className":"is-style-outline"} -->
			<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#news">Aktuelle News</a></div>
			<!-- /wp:button -->
		</div>
		<!-- /wp:buttons -->
	</div>
	<!-- /wp:group -->
</div></div>
<!-- /wp:cover -->
