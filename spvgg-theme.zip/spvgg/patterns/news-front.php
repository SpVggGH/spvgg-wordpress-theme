<?php
/**
 * Title: News auf der Startseite
 * Slug: spvgg/news-front
 * Categories: spvgg, query
 * Inserter: no
 * Description: Die neuesten Beiträge (Anzahl unter Einstellungen → Lesen) und ein Button zur News-Seite.
 */
?>
<!-- wp:query {"queryId":61,"query":{"perPage":<?php echo (int) spvgg_front_posts(); ?>,"pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","inherit":false},"align":"wide"} -->
<div class="wp-block-query alignwide">
	<!-- wp:post-template {"className":"spvgg-posts","layout":{"type":"grid","columnCount":3,"minimumColumnWidth":"18rem"}} -->
		<?php echo spvgg_post_card(); // phpcs:ignore WordPress.Security.EscapeOutput -- statisches Block-Markup ?>
	<!-- /wp:post-template -->

	<!-- wp:query-no-results -->
		<!-- wp:paragraph -->
		<p>Hier gibt es noch keine Beiträge.</p>
		<!-- /wp:paragraph -->
	<!-- /wp:query-no-results -->
</div>
<!-- /wp:query -->

<!-- wp:buttons {"align":"wide","layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|50"}}}} -->
<div class="wp-block-buttons alignwide" style="margin-top:var(--wp--preset--spacing--50)">
	<!-- wp:button {"className":"spvgg-news-link"} -->
	<div class="wp-block-button spvgg-news-link"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( spvgg_news_url() ); ?>">Alle News</a></div>
	<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
