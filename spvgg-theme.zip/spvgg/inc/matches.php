<?php
/**
 * Spielplan vom BFV: nächste Spiele und Ergebnisse je Mannschaft.
 *
 * Quelle sind die offiziellen iCal-Exporte des BFV (je Mannschaft ein Link, „iCal-Export“ auf der
 * Mannschaftsseite bei bfv.de). Die Exporte enthalten nur anstehende Spiele und keine Ergebnisse.
 * Deshalb werden alle Spiele hier gespeichert: Gespielte Spiele bleiben erhalten, das Ergebnis
 * tragen Redakteure unter „Spielplan“ im Backend ein.
 *
 * @package spvgg
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SPVGG_BFV_TEAMS', 'spvgg_bfv_teams' );     // [ [ 'name' => '1. Mannschaft', 'ics' => 'https://…' ], … ].
define( 'SPVGG_BFV_CLUB', 'spvgg_bfv_club' );       // Vereinsname wie beim BFV, z. B. „SpVgg Lagerlechfeld“.
define( 'SPVGG_BFV_MATCHES', 'spvgg_bfv_matches' ); // Gespeicherte Spiele, Schlüssel = BFV-Spielkennung (UID).
define( 'SPVGG_BFV_STATUS', 'spvgg_bfv_status' );   // Letzter Abruf je Mannschaft.
define( 'SPVGG_BFV_CRON', 'spvgg_bfv_refresh' );
define( 'SPVGG_BFV_MAX_AGE', 3 * HOUR_IN_SECONDS ); // Spätestens dann wird neu abgerufen.
define( 'SPVGG_BFV_DETAILS_PER_RUN', 12 );          // Spielseiten je Abruf (Wappen, Spieltag) – schont bfv.de.

/**
 * Konfigurierte Mannschaften, jeweils mit Schlüssel (aus dem Namen) für die Zuordnung der Spiele.
 */
function spvgg_bfv_teams() {
	$teams = array();
	foreach ( (array) get_option( SPVGG_BFV_TEAMS, array() ) as $team ) {
		if ( empty( $team['name'] ) || empty( $team['ics'] ) ) {
			continue;
		}
		$key           = sanitize_title( $team['name'] );
		$teams[ $key ] = array(
			'key'  => $key,
			'name' => $team['name'],
			'ics'  => $team['ics'],
		);
	}
	return $teams;
}

function spvgg_bfv_club() {
	return get_option( SPVGG_BFV_CLUB, 'SpVgg Lagerlechfeld' );
}

/*
 * ---------------------------------------------------------------------------
 * iCal einlesen
 * ---------------------------------------------------------------------------
 */

/**
 * Zerlegt eine iCal-Datei in Termine (nur die Felder, die wir brauchen).
 *
 * @param string $ics Inhalt der .ics-Datei.
 * @return array[] Je Termin: uid, start, end, summary, location.
 */
function spvgg_bfv_parse_ics( $ics ) {
	// Umbrochene Zeilen wieder zusammenfügen (RFC 5545: Folgezeile beginnt mit Leerzeichen oder Tab).
	$ics    = preg_replace( "/\r?\n[ \t]/", '', $ics );
	$events = array();
	if ( ! preg_match_all( '/BEGIN:VEVENT(.*?)END:VEVENT/s', $ics, $blocks ) ) {
		return $events;
	}
	foreach ( $blocks[1] as $block ) {
		$event = array();
		foreach ( preg_split( "/\r?\n/", trim( $block ) ) as $line ) {
			if ( ! preg_match( '/^([A-Z-]+)((?:;[^:]*)?):(.*)$/', $line, $m ) ) {
				continue;
			}
			list( , $name, $params, $value ) = $m;
			if ( 'DTSTART' === $name || 'DTEND' === $name ) {
				$event[ strtolower( substr( $name, 2 ) ) ] = spvgg_bfv_parse_date( $value, $params );
			} elseif ( in_array( $name, array( 'UID', 'SUMMARY', 'LOCATION' ), true ) ) {
				$event[ strtolower( $name ) ] = strtr(
					$value,
					array(
						'\\,'  => ',',
						'\\;'  => ';',
						'\\n'  => ' ',
						'\\N'  => ' ',
						'\\\\' => '\\',
					)
				);
			}
		}
		if ( ! empty( $event['uid'] ) && ! empty( $event['start'] ) && ! empty( $event['summary'] ) ) {
			$event += array(
				'end'      => $event['start'] + 2 * HOUR_IN_SECONDS,
				'location' => '',
			);
			$events[] = $event;
		}
	}
	return $events;
}

/**
 * Datum aus iCal in einen Zeitstempel umrechnen (UTC mit „Z“, mit TZID oder in Ortszeit).
 */
function spvgg_bfv_parse_date( $value, $params ) {
	$zone = wp_timezone();
	if ( 'Z' === substr( $value, -1 ) ) {
		$zone = new DateTimeZone( 'UTC' );
	} elseif ( preg_match( '/TZID=([^;]+)/', $params, $m ) ) {
		try {
			$zone = new DateTimeZone( trim( $m[1], '"' ) );
		} catch ( Exception $e ) {
			$zone = wp_timezone();
		}
	}
	$format = 8 === strlen( $value ) ? '!Ymd' : 'Ymd\THis';
	$date   = DateTimeImmutable::createFromFormat( $format, rtrim( $value, 'Z' ), $zone );
	return $date ? $date->getTimestamp() : 0;
}

/**
 * Macht aus einem iCal-Termin ein Spiel.
 * SUMMARY beim BFV: „Heim-Gast, Wettbewerb, Liga“ – Vereinsnamen können selbst Bindestriche enthalten,
 * darum wird am eigenen Vereinsnamen getrennt.
 */
function spvgg_bfv_event_to_match( $event, $team_key ) {
	$parts   = array_map( 'trim', explode( ',', $event['summary'] ) );
	$pairing = array_shift( $parts );
	$comp    = $parts ? array_shift( $parts ) : '';
	$league  = implode( ', ', $parts );

	list( $home, $away ) = spvgg_bfv_split_pairing( $pairing );

	// Ort: „Sportanlage,Straße,PLZ Stadt“ → Sportanlage und Stadt ohne Postleitzahl.
	$place = array_map( 'trim', explode( ',', $event['location'] ) );
	$city  = count( $place ) > 1 ? preg_replace( '/^\d{4,5}\s+/', '', end( $place ) ) : '';

	return array(
		'team'   => $team_key,
		'start'  => (int) $event['start'],
		'end'    => (int) $event['end'],
		'home'   => $home,
		'away'   => $away,
		'comp'   => $comp,
		'league' => $league,
		'venue'  => $place[0] ?? '',
		'city'   => $city,
	);
}

/**
 * Ist diese Seite der Paarung der eigene Verein? Auch Spielgemeinschaften wie
 * „(SG) TSV Beispiel/SpVgg Lagerlechfeld 2“ zählen.
 */
function spvgg_bfv_is_own( $side ) {
	$side = preg_replace( '/^\(SG\d*\)\s*/i', '', trim( $side ) );
	foreach ( explode( '/', $side ) as $part ) {
		if ( preg_match( '/^' . preg_quote( spvgg_bfv_club(), '/' ) . '(\s+\d+)?$/i', trim( $part ) ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Trennt „Heim-Gast“ an dem Bindestrich, bei dem genau eine Seite der eigene Verein ist
 * (Vereinsnamen wie „SV Gold-Blau Augsburg“ enthalten selbst Bindestriche).
 *
 * @return string[] [ Heim, Gast ].
 */
function spvgg_bfv_split_pairing( $pairing ) {
	$first  = null;
	$offset = 0;
	while ( false !== ( $pos = strpos( $pairing, '-', $offset ) ) ) {
		$home   = trim( substr( $pairing, 0, $pos ) );
		$away   = trim( substr( $pairing, $pos + 1 ) );
		$offset = $pos + 1;
		if ( '' === $home || '' === $away ) {
			continue;
		}
		$first = $first ?? array( $home, $away );
		if ( spvgg_bfv_is_own( $home ) xor spvgg_bfv_is_own( $away ) ) {
			return array( $home, $away );
		}
	}
	return $first ?? array( $pairing, '' );
}

/**
 * Ruft die iCal-Links aller Mannschaften ab und gleicht die gespeicherten Spiele ab.
 * Bereits gespielte Spiele bleiben stehen (der BFV-Export enthält sie nicht mehr),
 * anstehende Spiele, die aus dem Export verschwunden sind, werden entfernt (abgesagt/verlegt).
 */
function spvgg_bfv_refresh() {
	$matches = (array) get_option( SPVGG_BFV_MATCHES, array() );
	$status  = array();
	$now     = time();

	foreach ( spvgg_bfv_teams() as $key => $team ) {
		$response = wp_remote_get(
			$team['ics'],
			array(
				'timeout'    => 15,
				'user-agent' => 'Mozilla/5.0 (compatible; SpVgg-Website; ' . home_url() . ')',
			)
		);
		$code = wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );
		if ( is_wp_error( $response ) || 200 !== $code || false === strpos( $body, 'BEGIN:VCALENDAR' ) ) {
			$status[ $key ] = array(
				'time'  => $now,
				'error' => is_wp_error( $response ) ? $response->get_error_message() : sprintf( 'Antwort %s, kein Kalender', $code ),
			);
			continue; // Gespeicherte Spiele dieser Mannschaft unverändert lassen.
		}

		$seen = array();
		foreach ( spvgg_bfv_parse_ics( $body ) as $event ) {
			$uid          = sanitize_key( $event['uid'] );
			$seen[ $uid ] = true;
			// Ein bereits eingetragenes Ergebnis bleibt erhalten.
			$matches[ $uid ] = array_merge( $matches[ $uid ] ?? array(), spvgg_bfv_event_to_match( $event, $key ) );
		}
		foreach ( $matches as $uid => $match ) {
			if ( $key === $match['team'] && ! isset( $seen[ $uid ] ) && $match['end'] > $now ) {
				unset( $matches[ $uid ] );
			}
		}
		$status[ $key ] = array(
			'time'  => $now,
			'count' => count( $seen ),
		);
	}

	// Spiele älter als ein Jahr aufräumen.
	$matches = array_filter(
		$matches,
		function ( $match ) use ( $now ) {
			return $match['end'] > $now - YEAR_IN_SECONDS;
		}
	);
	uasort(
		$matches,
		function ( $a, $b ) {
			return $a['start'] <=> $b['start'];
		}
	);

	$matches = spvgg_bfv_fetch_details( $matches );
	// Fehlende Wappen nachladen (z. B. nach einem Update der Bildaufbereitung).
	foreach ( $matches as $match ) {
		foreach ( $match['clubs'] ?? array() as $club_id ) {
			spvgg_bfv_store_crest( $club_id );
		}
	}

	update_option( SPVGG_BFV_MATCHES, $matches, false );
	update_option( SPVGG_BFV_STATUS, $status, false );
}

/**
 * Wappen der Gegner und Spieltag von der öffentlichen Spielseite auf bfv.de holen.
 * Die iCal-Exporte enthalten beides nicht. Je Spiel genügt ein Abruf (der Gegner ändert sich nicht);
 * gelingt er nicht, wird es nach einem Tag erneut versucht. Zuerst die Spiele, die gerade angezeigt werden.
 *
 * @param array $matches Gespeicherte Spiele.
 * @return array Spiele, ergänzt um 'clubs' (Heim/Gast-Vereinskennung) und 'matchday'.
 */
function spvgg_bfv_fetch_details( $matches ) {
	$now  = time();
	$todo = array_filter(
		$matches,
		function ( $match ) use ( $now ) {
			return empty( $match['clubs'] ) && ( $match['details_tried'] ?? 0 ) < $now - DAY_IN_SECONDS;
		}
	);
	uasort(
		$todo,
		function ( $a, $b ) use ( $now ) {
			return abs( $a['start'] - $now ) <=> abs( $b['start'] - $now );
		}
	);

	foreach ( array_slice( array_keys( $todo ), 0, SPVGG_BFV_DETAILS_PER_RUN ) as $uid ) {
		$matches[ $uid ]['details_tried'] = $now;
		$response = wp_remote_get(
			'https://www.bfv.de/ergebnisse/spiel/-/' . strtoupper( $uid ),
			array(
				'timeout'    => 10,
				'user-agent' => 'Mozilla/5.0 (compatible; SpVgg-Website; ' . home_url() . ')',
			)
		);
		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			continue;
		}
		// Die Seite enthält die Spieldaten als (escaptes) JSON: …"homeTeam":{…"clubId":"…"}…
		$html  = str_replace( '\\"', '"', wp_remote_retrieve_body( $response ) );
		$clubs = array();
		foreach ( array( 'home' => 'homeTeam', 'away' => 'guestTeam' ) as $side => $field ) {
			$pos = strpos( $html, '"' . $field . '":{' );
			if ( false !== $pos && preg_match( '/"clubId":"([A-Z0-9]{20,40})"/', substr( $html, $pos, 800 ), $m ) ) {
				$clubs[ $side ] = $m[1];
				spvgg_bfv_store_crest( $m[1] );
			}
		}
		if ( 2 === count( $clubs ) ) {
			$matches[ $uid ]['clubs'] = $clubs;
			if ( preg_match( '/"matchday":(\d+)/', substr( $html, strpos( $html, '"homeTeam":{' ), 3000 ), $m ) ) {
				$matches[ $uid ]['matchday'] = (int) $m[1];
			}
		}
	}
	return $matches;
}

/**
 * Ablage der Wappen in den Uploads – Besucher laden so nichts von bfv.de nach (Datenschutz).
 *
 * @return array{dir:string,url:string}
 */
function spvgg_bfv_crest_dir() {
	$uploads = wp_upload_dir( null, false );
	return array(
		'dir' => $uploads['basedir'] . '/spvgg-wappen',
		'url' => $uploads['baseurl'] . '/spvgg-wappen',
	);
}

/**
 * Dateiname eines gespeicherten Wappens. Die Endung „-2“ steht für die Aufbereitung
 * (weißer Rand entfernt); ändert sie sich, werden die Wappen neu geladen.
 */
function spvgg_bfv_crest_name( $club_id ) {
	return $club_id . '-2.png';
}

/**
 * Lädt das Wappen eines Vereins einmalig vom BFV und speichert es als PNG.
 */
function spvgg_bfv_store_crest( $club_id ) {
	$where = spvgg_bfv_crest_dir();
	$file  = $where['dir'] . '/' . spvgg_bfv_crest_name( $club_id );
	if ( file_exists( $file ) || ! wp_mkdir_p( $where['dir'] ) ) {
		return;
	}
	wp_delete_file( $where['dir'] . '/' . $club_id . '.png' ); // Vorgängerversion ohne Aufbereitung.
	$response = wp_remote_get(
		'https://app.bfv.de/export.media/-/action/getLogo/id/' . $club_id . '/verband/00ES8GNCQK000000VV0AG08LVUPGND5I/strat_code/bfv',
		array( 'timeout' => 10 )
	);
	$png = wp_remote_retrieve_body( $response );
	// Nur echte, kleine PNG-Dateien übernehmen.
	if ( 200 === wp_remote_retrieve_response_code( $response ) && "\x89PNG" === substr( $png, 0, 4 ) && strlen( $png ) < 300 * KB_IN_BYTES ) {
		file_put_contents( $file, spvgg_bfv_clear_background( $png ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- Datei in eigenem Upload-Ordner
	}
}

/**
 * Macht den weißen Hintergrund um ein Wappen transparent.
 * Entfernt wird nur Weiß, das mit dem Bildrand verbunden ist (Flutfüllung) – weiße Flächen
 * im Wappen selbst bleiben. Kanten werden weich ausgeblendet, damit auf Gelb kein Rand bleibt.
 *
 * @param string $png PNG-Daten.
 * @return string Bearbeitete PNG-Daten (oder unverändert, wenn GD fehlt oder etwas schiefgeht).
 */
function spvgg_bfv_clear_background( $png ) {
	if ( ! function_exists( 'imagecreatefromstring' ) ) {
		return $png;
	}
	$img = @imagecreatefromstring( $png ); // phpcs:ignore WordPress.PHP.NoSilencedErrors -- ungültige Bilder einfach überspringen
	if ( ! $img ) {
		return $png;
	}
	if ( ! imageistruecolor( $img ) ) {
		imagepalettetotruecolor( $img );
	}
	imagealphablending( $img, false );
	imagesavealpha( $img, true );

	$w = imagesx( $img );
	$h = imagesy( $img );
	// Helligkeit des dunkelsten Farbkanals; transparente Pixel zählen als Hintergrund.
	$light = function ( $x, $y ) use ( $img ) {
		$c = imagecolorat( $img, $x, $y );
		if ( ( ( $c >> 24 ) & 127 ) > 100 ) {
			return 255;
		}
		return min( ( $c >> 16 ) & 255, ( $c >> 8 ) & 255, $c & 255 );
	};

	$bg    = array();
	$queue = array();
	for ( $x = 0; $x < $w; $x++ ) {
		$queue[] = array( $x, 0 );
		$queue[] = array( $x, $h - 1 );
	}
	for ( $y = 0; $y < $h; $y++ ) {
		$queue[] = array( 0, $y );
		$queue[] = array( $w - 1, $y );
	}
	while ( $queue ) {
		list( $x, $y ) = array_pop( $queue );
		$i = $y * $w + $x;
		if ( $x < 0 || $y < 0 || $x >= $w || $y >= $h || isset( $bg[ $i ] ) || $light( $x, $y ) < 232 ) {
			continue;
		}
		$bg[ $i ] = true;
		array_push( $queue, array( $x + 1, $y ), array( $x - 1, $y ), array( $x, $y + 1 ), array( $x, $y - 1 ) );
	}
	// Kein weißer Rand – oder fast alles weiß (z. B. weißes Wappen auf Weiß): lieber unverändert lassen.
	if ( ! $bg || count( $bg ) > 0.9 * $w * $h ) {
		imagedestroy( $img );
		return $png;
	}

	$clear = imagecolorallocatealpha( $img, 255, 255, 255, 127 );
	foreach ( array_keys( $bg ) as $i ) {
		imagesetpixel( $img, $i % $w, intdiv( $i, $w ), $clear );
	}
	// Helle Kantenpixel neben dem entfernten Hintergrund teilweise transparent machen.
	for ( $y = 0; $y < $h; $y++ ) {
		for ( $x = 0; $x < $w; $x++ ) {
			$i = $y * $w + $x;
			if ( isset( $bg[ $i ] ) || ! ( isset( $bg[ $i - 1 ] ) || isset( $bg[ $i + 1 ] ) || isset( $bg[ $i - $w ] ) || isset( $bg[ $i + $w ] ) ) ) {
				continue;
			}
			$l = $light( $x, $y );
			if ( $l > 170 ) {
				$c = imagecolorat( $img, $x, $y );
				$a = max( ( $c >> 24 ) & 127, (int) round( 127 * ( $l - 170 ) / 62 ) );
				imagesetpixel( $img, $x, $y, imagecolorallocatealpha( $img, ( $c >> 16 ) & 255, ( $c >> 8 ) & 255, $c & 255, min( 127, $a ) ) );
			}
		}
	}

	ob_start();
	imagepng( $img );
	imagedestroy( $img );
	$out = ob_get_clean();
	return $out ? $out : $png;
}
add_action( SPVGG_BFV_CRON, 'spvgg_bfv_refresh' );

// Stündlich prüfen; der eigentliche Abruf läuft nur, wenn die Daten älter als SPVGG_BFV_MAX_AGE sind.
add_action(
	'init',
	function () {
		if ( ! wp_next_scheduled( SPVGG_BFV_CRON ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', SPVGG_BFV_CRON );
		}
	}
);

add_action(
	'switch_theme',
	function () {
		wp_clear_scheduled_hook( SPVGG_BFV_CRON );
	}
);

/**
 * Sind die Daten zu alt, im Hintergrund neu abrufen lassen (die Seite selbst wartet nicht darauf).
 */
function spvgg_bfv_maybe_refresh() {
	$status = (array) get_option( SPVGG_BFV_STATUS, array() );
	$oldest = $status ? min( wp_list_pluck( $status, 'time' ) ) : 0;
	if ( spvgg_bfv_teams() && $oldest < time() - SPVGG_BFV_MAX_AGE && ! wp_next_scheduled( SPVGG_BFV_CRON . '_now' ) ) {
		wp_schedule_single_event( time(), SPVGG_BFV_CRON . '_now' );
	}
}
add_action( SPVGG_BFV_CRON . '_now', 'spvgg_bfv_refresh' );

/*
 * ---------------------------------------------------------------------------
 * Auswahl und Darstellung
 * ---------------------------------------------------------------------------
 */

/**
 * Je Mannschaft das nächste Spiel bzw. das letzte Spiel mit Ergebnis.
 *
 * @param string $mode 'next' oder 'results'.
 * @return array Schlüssel = Mannschaft, Wert = Spiel oder null.
 */
function spvgg_bfv_pick( $mode ) {
	$matches = (array) get_option( SPVGG_BFV_MATCHES, array() );
	$now     = time();
	$picked  = array();
	foreach ( spvgg_bfv_teams() as $key => $team ) {
		$picked[ $key ] = null;
	}
	foreach ( $matches as $uid => $match ) {
		if ( ! array_key_exists( $match['team'], $picked ) ) {
			continue;
		}
		$match['uid'] = $uid;
		if ( 'next' === $mode ) {
			// Erstes Spiel, das noch nicht vorbei ist (läuft es gerade, bleibt es hier stehen).
			if ( $match['end'] > $now && empty( $match['score'] ) && null === $picked[ $match['team'] ] ) {
				$picked[ $match['team'] ] = $match;
			}
		} elseif ( ! empty( $match['score'] ) ) {
			// Liste ist nach Anstoß sortiert – das letzte mit Ergebnis gewinnt.
			$picked[ $match['team'] ] = $match;
		}
	}
	return $picked;
}

/**
 * Liga-Kürzel des BFV ausschreiben („KL Augsburg“ → „Kreisliga Augsburg“).
 */
function spvgg_bfv_league_label( $league ) {
	$names = array(
		'RL'  => 'Regionalliga',
		'BL'  => 'Bayernliga',
		'LL'  => 'Landesliga',
		'BZL' => 'Bezirksliga',
		'KL'  => 'Kreisliga',
		'KK'  => 'Kreisklasse',
		'AK'  => 'A-Klasse',
		'BK'  => 'B-Klasse',
		'CK'  => 'C-Klasse',
	);
	return preg_replace_callback(
		'/^([A-Z]{2,3})\b/',
		function ( $m ) use ( $names ) {
			return $names[ $m[1] ] ?? $m[1];
		},
		$league
	);
}

function spvgg_bfv_comp_label( $comp ) {
	$names = array(
		'Meisterschaften'     => 'Meisterschaft',
		'Freundschaftsspiele' => 'Freundschaftsspiel',
		'Pokalspiele'         => 'Pokal',
		'Hallenturniere'      => 'Hallenturnier',
	);
	return $names[ $comp ] ?? $comp;
}

/**
 * Wappen: eigener Verein = Website-Logo, Gegner = vom BFV gespeichertes Wappen, sonst Kürzel.
 */
function spvgg_bfv_crest( $name, $club_id = '' ) {
	if ( spvgg_bfv_is_own( $name ) ) {
		$logo = get_theme_mod( 'custom_logo' ) ? wp_get_attachment_image_url( get_theme_mod( 'custom_logo' ), 'medium' ) : '';
		$logo = $logo ? $logo : get_theme_file_uri( 'assets/images/logo.png' );
		return sprintf( '<img class="spvgg-match__crest" src="%s" alt="" loading="lazy" decoding="async">', esc_url( $logo ) );
	}
	$where = spvgg_bfv_crest_dir();
	if ( $club_id && file_exists( $where['dir'] . '/' . spvgg_bfv_crest_name( $club_id ) ) ) {
		return sprintf( '<img class="spvgg-match__crest" src="%s" alt="" width="64" height="64" loading="lazy" decoding="async">', esc_url( $where['url'] . '/' . spvgg_bfv_crest_name( $club_id ) ) );
	}
	// Kürzel aus den markanten Wörtern: „SV Gold-Blau Augsburg“ → „GA“, „TSV Bobingen 2“ → „BO“.
	$words = preg_split( '/[\s\/]+/', preg_replace( '/\(.*?\)|\b\d+\b/u', ' ', $name ), -1, PREG_SPLIT_NO_EMPTY );
	$words = array_values(
		array_filter(
			$words,
			function ( $word ) {
				return ! preg_match( '/^(SV|TSV|FC|SC|SpVgg|DJK|VfL|VfB|TV|TSG|SG|SSV|ESV|FSV|BSC|ASV|JFG|e\.?V\.?)$/i', $word );
			}
		)
	);
	if ( ! $words ) {
		$initials = mb_substr( $name, 0, 2 );
	} elseif ( 1 === count( $words ) ) {
		$initials = mb_substr( $words[0], 0, 2 );
	} else {
		$initials = mb_substr( $words[0], 0, 1 ) . mb_substr( end( $words ), 0, 1 );
	}
	return sprintf( '<span class="spvgg-match__crest spvgg-match__crest--initials" aria-hidden="true">%s</span>', esc_html( mb_strtoupper( $initials ) ) );
}

/**
 * Eine Spielkarte im Stil von bvb.de.
 */
function spvgg_bfv_card( $team, $match, $mode ) {
	ob_start();
	?>
	<article class="spvgg-match<?php echo $match ? '' : ' is-empty'; ?>">
		<header class="spvgg-match__head">
			<span class="spvgg-match__team-name"><?php echo esc_html( $team['name'] ); ?></span>
			<?php if ( $match && $match['league'] ) : ?>
				<span class="spvgg-match__league"><?php echo esc_html( spvgg_bfv_league_label( $match['league'] ) ); ?></span>
			<?php endif; ?>
		</header>
		<div class="spvgg-match__body">
			<?php if ( ! $match ) : ?>
				<p class="spvgg-match__empty"><?php echo 'next' === $mode ? 'Aktuell ist kein Spiel angesetzt.' : 'Noch kein Ergebnis eingetragen.'; ?></p>
			<?php else : ?>
				<p class="spvgg-match__comp"><?php echo esc_html( spvgg_bfv_comp_label( $match['comp'] ) . ( empty( $match['matchday'] ) ? '' : ', ' . $match['matchday'] . '. Spieltag' ) ); ?></p>
				<p class="spvgg-match__date">
					<time datetime="<?php echo esc_attr( wp_date( 'c', $match['start'] ) ); ?>">
						<?php echo esc_html( wp_date( 'D d.m.Y', $match['start'] ) ); ?><?php echo 'next' === $mode ? esc_html( ' · ' . wp_date( 'H:i', $match['start'] ) . ' Uhr' ) : ''; ?>
					</time>
				</p>
				<p class="spvgg-match__venue"><?php echo esc_html( implode( ', ', array_filter( array( $match['venue'], $match['city'] ) ) ) ); ?></p>
				<div class="spvgg-match__teams">
					<div class="spvgg-match__side">
						<?php echo spvgg_bfv_crest( $match['home'], $match['clubs']['home'] ?? '' ); // phpcs:ignore WordPress.Security.EscapeOutput -- in spvgg_bfv_crest() escaped ?>
						<span class="spvgg-match__club"><?php echo esc_html( $match['home'] ); ?></span>
					</div>
					<?php if ( 'results' === $mode ) : ?>
						<?php list( $home_goals, $away_goals ) = array_map( 'trim', explode( ':', $match['score'] ) ); ?>
						<p class="spvgg-match__score" aria-label="<?php echo esc_attr( sprintf( 'Ergebnis %s zu %s', $home_goals, $away_goals ) ); ?>"><span><?php echo esc_html( $home_goals ); ?></span><span class="spvgg-match__colon">:</span><span><?php echo esc_html( $away_goals ); ?></span></p>
					<?php else : ?>
						<p class="spvgg-match__vs" aria-label="gegen">VS</p>
					<?php endif; ?>
					<div class="spvgg-match__side">
						<?php echo spvgg_bfv_crest( $match['away'], $match['clubs']['away'] ?? '' ); // phpcs:ignore WordPress.Security.EscapeOutput -- in spvgg_bfv_crest() escaped ?>
						<span class="spvgg-match__club"><?php echo esc_html( $match['away'] ); ?></span>
					</div>
				</div>
				<a class="spvgg-match__link" href="<?php echo esc_url( 'https://www.bfv.de/ergebnisse/spiel/-/' . strtoupper( $match['uid'] ) ); ?>" target="_blank" rel="noopener">
					<?php echo 'next' === $mode ? 'Zum Spiel' : 'Spielbericht'; ?><span class="screen-reader-text"> (bfv.de, neues Fenster)</span>
				</a>
			<?php endif; ?>
		</div>
	</article>
	<?php
	return ob_get_clean();
}

/**
 * Ausgabe des Blocks „Spiele (BFV)“: Umschalter und je Ansicht eine Karte pro Mannschaft.
 */
function spvgg_bfv_render_block( $attributes = array() ) {
	$teams = spvgg_bfv_teams();
	if ( ! $teams ) {
		if ( current_user_can( 'manage_options' ) ) {
			return sprintf(
				'<p class="spvgg-matches__notice">Noch keine Mannschaften hinterlegt. <a href="%s">Spielplan einrichten</a></p>',
				esc_url( admin_url( 'admin.php?page=spvgg-spielplan' ) )
			);
		}
		return '';
	}
	spvgg_bfv_maybe_refresh();

	$id      = wp_unique_id( 'spvgg-matches-' );
	$default = ( $attributes['view'] ?? 'next' ) === 'results' ? 'results' : 'next';
	$views   = array(
		'next'    => 'Nächste Spiele',
		'results' => 'Ergebnisse',
	);

	wp_enqueue_script( 'spvgg-matches', get_theme_file_uri( 'assets/js/matches.js' ), array(), SPVGG_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );

	$heading = $attributes['heading'] ?? 'Spiele';

	ob_start();
	?>
	<div class="spvgg-matches__head">
		<?php if ( $heading ) : ?>
			<h2 class="wp-block-heading spvgg-matches__title"><?php echo esc_html( $heading ); ?></h2>
		<?php endif; ?>
		<div class="spvgg-matches__tabs" role="tablist" aria-label="<?php echo esc_attr( $heading ? $heading : 'Spiele' ); ?>">
			<?php foreach ( $views as $view => $label ) : ?>
				<button type="button" role="tab" class="spvgg-matches__tab" id="<?php echo esc_attr( "$id-tab-$view" ); ?>" aria-controls="<?php echo esc_attr( "$id-$view" ); ?>" aria-selected="<?php echo $view === $default ? 'true' : 'false'; ?>" tabindex="<?php echo $view === $default ? '0' : '-1'; ?>"><?php echo esc_html( $label ); ?></button>
			<?php endforeach; ?>
		</div>
	</div>
	<?php foreach ( $views as $view => $label ) : ?>
		<div class="spvgg-matches__panel" role="tabpanel" id="<?php echo esc_attr( "$id-$view" ); ?>" aria-labelledby="<?php echo esc_attr( "$id-tab-$view" ); ?>"<?php echo $view === $default ? '' : ' hidden'; ?>>
			<?php
			foreach ( spvgg_bfv_pick( $view ) as $key => $match ) {
				echo spvgg_bfv_card( $teams[ $key ], $match, $view ); // phpcs:ignore WordPress.Security.EscapeOutput -- in spvgg_bfv_card() escaped
			}
			?>
		</div>
	<?php endforeach; ?>
	<?php
	$wrapper = get_block_wrapper_attributes( array( 'class' => 'spvgg-matches' ) );
	return sprintf( '<div %s>%s</div>', $wrapper, ob_get_clean() );
}

add_action(
	'init',
	function () {
		wp_register_script( 'spvgg-matches-editor', get_theme_file_uri( 'assets/js/matches-editor.js' ), array( 'wp-blocks', 'wp-element', 'wp-server-side-render', 'wp-block-editor', 'wp-components' ), SPVGG_VERSION, true );
		register_block_type(
			get_theme_file_path( 'blocks/matches' ),
			array( 'render_callback' => 'spvgg_bfv_render_block' )
		);
	}
);

/*
 * ---------------------------------------------------------------------------
 * Backend: Mannschaften einrichten und Ergebnisse eintragen
 * ---------------------------------------------------------------------------
 */

add_action(
	'admin_menu',
	function () {
		add_menu_page( 'Spielplan', 'Spielplan', 'edit_others_posts', 'spvgg-spielplan', 'spvgg_bfv_admin_page', 'dashicons-calendar-alt', 6 );
	}
);

function spvgg_bfv_admin_page() {
	$teams   = (array) get_option( SPVGG_BFV_TEAMS, array() );
	$status  = (array) get_option( SPVGG_BFV_STATUS, array() );
	$matches = (array) get_option( SPVGG_BFV_MATCHES, array() );
	$admin   = current_user_can( 'manage_options' );
	$names   = wp_list_pluck( spvgg_bfv_teams(), 'name', 'key' );
	$now     = time();

	// Gespielte Spiele der letzten 60 Tage, neueste zuerst.
	$played = array_reverse(
		array_filter(
			$matches,
			function ( $match ) use ( $now, $names ) {
				return $match['end'] <= $now && $match['start'] > $now - 60 * DAY_IN_SECONDS && isset( $names[ $match['team'] ] );
			}
		),
		true
	);
	?>
	<div class="wrap spvgg-spielplan-admin">
		<h1>Spielplan</h1>
		<?php if ( isset( $_GET['updated'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification ?>
			<div class="notice notice-success is-dismissible"><p>Gespeichert.</p></div>
		<?php endif; ?>
		<p>Anstehende Spiele kommen automatisch vom BFV. Ergebnisse liefert der BFV nicht mit – trage sie nach dem Spiel hier ein, dann erscheinen sie auf der Website unter „Ergebnisse“.</p>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="spvgg_spielplan">
			<?php wp_nonce_field( 'spvgg_spielplan' ); ?>

			<h2>Ergebnisse</h2>
			<?php if ( ! $played ) : ?>
				<p><em>Noch keine gespielten Spiele. Spiele erscheinen hier, sobald sie vorbei sind.</em></p>
			<?php else : ?>
				<table class="widefat striped" style="max-width:900px">
					<thead><tr><th>Datum</th><th>Mannschaft</th><th>Spiel</th><th style="width:7rem">Ergebnis</th></tr></thead>
					<tbody>
					<?php foreach ( $played as $uid => $match ) : ?>
						<tr>
							<td><?php echo esc_html( wp_date( 'D d.m.Y', $match['start'] ) ); ?></td>
							<td><?php echo esc_html( $names[ $match['team'] ] ); ?></td>
							<td><?php echo esc_html( $match['home'] . ' – ' . $match['away'] ); ?></td>
							<td><input type="text" name="score[<?php echo esc_attr( $uid ); ?>]" value="<?php echo esc_attr( $match['score'] ?? '' ); ?>" placeholder="z. B. 2:1" pattern="\s*\d{1,2}\s*:\s*\d{1,2}\s*" inputmode="numeric" size="6" aria-label="<?php echo esc_attr( 'Ergebnis ' . $match['home'] . ' gegen ' . $match['away'] ); ?>"></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>

			<?php if ( $admin ) : ?>
				<h2 style="margin-top:2.5rem">Mannschaften</h2>
				<p>Je Mannschaft den Link „iCal-Export“ von der Mannschaftsseite auf bfv.de einfügen. <strong>Zur neuen Saison ändert sich der Link</strong> – dann hier ersetzen. Eine leere Zeile entfernt die Mannschaft.</p>
				<table class="widefat" style="max-width:900px">
					<thead><tr><th style="width:12rem">Bezeichnung</th><th>iCal-Link vom BFV</th><th style="width:14rem">Letzter Abruf</th></tr></thead>
					<tbody>
					<?php foreach ( array_merge( $teams, array( array( 'name' => '', 'ics' => '' ) ) ) as $i => $team ) : ?>
						<?php $info = $status[ sanitize_title( $team['name'] ) ] ?? null; ?>
						<tr>
							<td><input type="text" class="regular-text" style="width:100%" name="teams[<?php echo (int) $i; ?>][name]" value="<?php echo esc_attr( $team['name'] ); ?>" placeholder="z. B. 1. Mannschaft"></td>
							<td><input type="url" class="large-text" name="teams[<?php echo (int) $i; ?>][ics]" value="<?php echo esc_attr( $team['ics'] ); ?>" placeholder="https://service.bfv.de/rest/icsexport/Spielplan?staffel=…"></td>
							<td>
								<?php if ( ! $info ) : ?>
									–
								<?php elseif ( ! empty( $info['error'] ) ) : ?>
									<span style="color:#b32d2e"><?php echo esc_html( 'Fehler: ' . $info['error'] ); ?></span>
								<?php else : ?>
									<?php echo esc_html( sprintf( '%s · %d Spiele', wp_date( 'd.m. H:i', $info['time'] ), $info['count'] ) ); ?>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<p>
					<label>Vereinsname wie beim BFV <input type="text" name="club" value="<?php echo esc_attr( spvgg_bfv_club() ); ?>"></label>
					<br><span class="description">Damit wird erkannt, welche Seite in der Paarung euer Verein ist.</span>
				</p>
			<?php endif; ?>

			<p class="submit">
				<?php submit_button( 'Speichern', 'primary', 'save', false ); ?>
				<?php submit_button( 'Speichern und jetzt vom BFV abrufen', 'secondary', 'refresh', false ); ?>
			</p>
		</form>
	</div>
	<?php
}

add_action(
	'admin_post_spvgg_spielplan',
	function () {
		if ( ! current_user_can( 'edit_others_posts' ) ) {
			wp_die( 'Keine Berechtigung.' );
		}
		check_admin_referer( 'spvgg_spielplan' );

		$matches = (array) get_option( SPVGG_BFV_MATCHES, array() );
		foreach ( (array) ( $_POST['score'] ?? array() ) as $uid => $score ) {
			$uid   = sanitize_key( $uid );
			$score = sanitize_text_field( wp_unslash( $score ) );
			if ( ! isset( $matches[ $uid ] ) ) {
				continue;
			}
			if ( preg_match( '/^(\d{1,2})\s*:\s*(\d{1,2})$/', $score, $m ) ) {
				$matches[ $uid ]['score'] = $m[1] . ':' . $m[2];
			} else {
				unset( $matches[ $uid ]['score'] );
			}
		}
		update_option( SPVGG_BFV_MATCHES, $matches, false );

		if ( current_user_can( 'manage_options' ) && isset( $_POST['teams'] ) ) {
			$teams = array();
			foreach ( (array) wp_unslash( $_POST['teams'] ) as $team ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- Felder werden einzeln bereinigt
				$name = sanitize_text_field( $team['name'] ?? '' );
				$ics  = esc_url_raw( trim( $team['ics'] ?? '' ), array( 'https', 'http' ) );
				if ( $name && $ics ) {
					$teams[] = array(
						'name' => $name,
						'ics'  => $ics,
					);
				}
			}
			update_option( SPVGG_BFV_TEAMS, $teams );
			$club = sanitize_text_field( wp_unslash( $_POST['club'] ?? '' ) );
			update_option( SPVGG_BFV_CLUB, $club ? $club : 'SpVgg Lagerlechfeld' );
		}

		if ( isset( $_POST['refresh'] ) ) {
			spvgg_bfv_refresh();
		}

		wp_safe_redirect( admin_url( 'admin.php?page=spvgg-spielplan&updated=1' ) );
		exit;
	}
);
