<?php
/**
 * SpVgg Lagerlechfeld-Graben – Theme-Funktionen.
 *
 * @package spvgg
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SPVGG_VERSION', wp_get_theme()->get( 'Version' ) );

require_once __DIR__ . '/inc/matches.php';

/**
 * Theme-Unterstützung und Editor-Styles.
 */
add_action(
	'after_setup_theme',
	function () {
		add_theme_support( 'wp-block-styles' );
		add_theme_support( 'editor-styles' );
		add_editor_style( 'assets/css/theme.css' );
	}
);

/**
 * Zusätzliches CSS (Hover-Effekte, Streifenmuster aus dem Wappen usw.).
 */
add_action(
	'wp_enqueue_scripts',
	function () {
		wp_enqueue_style( 'spvgg', get_theme_file_uri( 'assets/css/theme.css' ), array(), SPVGG_VERSION );
		if ( is_page_template( 'page-abteilung' ) ) {
			wp_enqueue_script( 'spvgg-dept-tiles', get_theme_file_uri( 'assets/js/dept-tiles.js' ), array(), SPVGG_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
		}
		wp_enqueue_script(
			'spvgg-menu',
			get_theme_file_uri( 'assets/js/menu.js' ),
			array(),
			SPVGG_VERSION,
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
	}
);

/**
 * Eigene Muster-Kategorie, damit die Vereins-Blöcke im Editor gebündelt sind.
 */
add_action(
	'init',
	function () {
		register_block_pattern_category( 'spvgg', array( 'label' => __( 'SpVgg', 'spvgg' ) ) );

		register_block_style(
			'core/group',
			array(
				'name'  => 'spvgg-stripes',
				'label' => __( 'Wappen-Streifen', 'spvgg' ),
			)
		);
		register_block_style(
			'core/group',
			array(
				'name'  => 'spvgg-card',
				'label' => __( 'Karte', 'spvgg' ),
			)
		);
		// Für die Kacheln auf Abteilungsseiten: kompakte Chips statt Slider (alles sichtbar, kein Scrollen).
		register_block_style(
			'core/group',
			array(
				'name'  => 'spvgg-chips',
				'label' => __( 'Kompakt (Chips)', 'spvgg' ),
			)
		);
		// Für den Header: großes Wappen, das unten in den Inhalt hineinragt.
		register_block_style(
			'core/group',
			array(
				'name'  => 'spvgg-logo-overlap',
				'label' => __( 'Logo ragt hinein', 'spvgg' ),
			)
		);
	}
);

/**
 * Beim Aktivieren das Vereinswappen als Website-Logo hinterlegen, falls noch keins gesetzt ist.
 * Danach lässt es sich ganz normal im Website-Editor austauschen.
 */
add_action(
	'after_switch_theme',
	function () {
		if ( get_option( 'site_logo' ) || get_theme_mod( 'custom_logo' ) ) {
			return;
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$tmp = wp_tempnam( 'spvgg-wappen.png' );
		if ( ! $tmp || ! copy( get_theme_file_path( 'assets/images/logo.png' ), $tmp ) ) {
			return;
		}
		$id = media_handle_sideload( array( 'name' => 'spvgg-wappen.png', 'tmp_name' => $tmp ), 0, 'SpVgg Wappen' );
		if ( is_wp_error( $id ) ) {
			wp_delete_file( $tmp );
			return;
		}
		update_option( 'site_logo', $id );
		set_theme_mod( 'custom_logo', $id );
	}
);

/**
 * Kategorie-Bild: pro Kategorie ein Foto, das in den News-Karten erscheint,
 * wenn ein Beitrag kein eigenes Beitragsbild hat.
 * Auswahl unter Beiträge → Kategorien → Kategorie bearbeiten.
 */
define( 'SPVGG_CAT_IMAGE', 'spvgg_cat_image' );

add_action(
	'init',
	function () {
		register_term_meta(
			'category',
			SPVGG_CAT_IMAGE,
			array(
				'type'              => 'integer',
				'single'            => true,
				'sanitize_callback' => 'absint',
				'show_in_rest'      => true,
			)
		);
	}
);

/**
 * Feld im Kategorie-Formular (Bearbeiten und Neu anlegen).
 *
 * @param WP_Term|string $term Kategorie beim Bearbeiten, Taxonomie-Slug beim Anlegen.
 */
function spvgg_cat_image_field( $term ) {
	$id      = $term instanceof WP_Term ? (int) get_term_meta( $term->term_id, SPVGG_CAT_IMAGE, true ) : 0;
	$preview = $id ? wp_get_attachment_image( $id, 'medium', false, array( 'style' => 'max-width:300px;height:auto;display:block;margin-bottom:8px' ) ) : '';
	wp_nonce_field( 'spvgg_cat_image', 'spvgg_cat_image_nonce' );
	?>
	<div class="spvgg-cat-image">
		<div class="spvgg-cat-image__preview"><?php echo $preview; // phpcs:ignore WordPress.Security.EscapeOutput -- von wp_get_attachment_image escaped ?></div>
		<input type="hidden" name="<?php echo esc_attr( SPVGG_CAT_IMAGE ); ?>" value="<?php echo esc_attr( $id ?: '' ); ?>">
		<button type="button" class="button spvgg-cat-image__pick"><?php esc_html_e( 'Bild wählen', 'spvgg' ); ?></button>
		<button type="button" class="button-link spvgg-cat-image__remove" <?php echo $id ? '' : 'hidden'; ?>><?php esc_html_e( 'Entfernen', 'spvgg' ); ?></button>
		<p class="description"><?php esc_html_e( 'Erscheint in den News-Karten mit dem Kategorienamen, wenn ein Beitrag kein eigenes Beitragsbild hat. Ohne Auswahl wird das Hero-Foto verwendet.', 'spvgg' ); ?></p>
	</div>
	<?php
}

add_action(
	'category_edit_form_fields',
	function ( $term ) {
		echo '<tr class="form-field"><th scope="row">' . esc_html__( 'Kategorie-Bild', 'spvgg' ) . '</th><td>';
		spvgg_cat_image_field( $term );
		echo '</td></tr>';
	}
);
add_action(
	'category_add_form_fields',
	function ( $taxonomy ) {
		echo '<div class="form-field"><label>' . esc_html__( 'Kategorie-Bild', 'spvgg' ) . '</label>';
		spvgg_cat_image_field( $taxonomy );
		echo '</div>';
	}
);

/**
 * Speichern beim Anlegen und Bearbeiten.
 *
 * @param int $term_id Kategorie-ID.
 */
function spvgg_cat_image_save( $term_id ) {
	if ( ! isset( $_POST['spvgg_cat_image_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['spvgg_cat_image_nonce'] ), 'spvgg_cat_image' ) ) {
		return;
	}
	if ( ! current_user_can( 'edit_term', $term_id ) ) {
		return;
	}
	$id = isset( $_POST[ SPVGG_CAT_IMAGE ] ) ? absint( $_POST[ SPVGG_CAT_IMAGE ] ) : 0;
	if ( $id ) {
		update_term_meta( $term_id, SPVGG_CAT_IMAGE, $id );
	} else {
		delete_term_meta( $term_id, SPVGG_CAT_IMAGE );
	}
}
add_action( 'edited_category', 'spvgg_cat_image_save' );
add_action( 'created_category', 'spvgg_cat_image_save' );

/**
 * Mediathek-Auswahl im Kategorie-Formular.
 *
 * @param string $hook Admin-Seite.
 */
add_action(
	'admin_enqueue_scripts',
	function ( $hook ) {
		if ( ! in_array( $hook, array( 'edit-tags.php', 'term.php' ), true ) || 'category' !== get_current_screen()->taxonomy ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_script( 'spvgg-cat-image', get_theme_file_uri( 'assets/js/cat-image.js' ), array( 'jquery' ), SPVGG_VERSION, true );
	}
);

/**
 * Ersatzbild für Karten ohne Beitragsbild: Kategorie-Foto (oder Hero-Foto) mit Kategoriename.
 * Greift nur beim Beitragsbild-Block mit der Klasse „spvgg-card-image“, nicht auf der Beitragsseite.
 *
 * @param string   $html   Ausgabe des Blocks (leer, wenn kein Beitragsbild).
 * @param array    $block  Geparster Block.
 * @param WP_Block $instance Block-Instanz mit Kontext.
 */
add_filter(
	'render_block_core/post-featured-image',
	function ( $html, $block, $instance ) {
		$class = $block['attrs']['className'] ?? '';
		if ( '' !== trim( $html ) || false === strpos( $class, 'spvgg-card-image' ) ) {
			return $html;
		}
		$post_id = $instance->context['postId'] ?? get_the_ID();
		if ( ! $post_id ) {
			return $html;
		}

		$cats  = get_the_category( $post_id );
		$cat   = $cats ? $cats[0] : null;
		$image = $cat ? (int) get_term_meta( $cat->term_id, SPVGG_CAT_IMAGE, true ) : 0;
		$img   = $image
			? wp_get_attachment_image( $image, 'large', false, array( 'alt' => '', 'loading' => 'lazy' ) )
			: sprintf( '<img src="%s" alt="" loading="lazy" decoding="async">', esc_url( get_theme_file_uri( 'assets/images/hero.jpg' ) ) );
		if ( ! $img ) { // Bild in der Mediathek gelöscht
			$img = sprintf( '<img src="%s" alt="" loading="lazy" decoding="async">', esc_url( get_theme_file_uri( 'assets/images/hero.jpg' ) ) );
		}

		$ratio = $block['attrs']['aspectRatio'] ?? '16/10';
		return sprintf(
			'<figure class="wp-block-post-featured-image %1$s spvgg-fallback" style="aspect-ratio:%2$s"><a href="%3$s" tabindex="-1" aria-hidden="true">%4$s<span class="spvgg-fallback__label">%5$s</span></a></figure>',
			esc_attr( $class ),
			esc_attr( $ratio ),
			esc_url( get_permalink( $post_id ) ),
			$img,
			esc_html( $cat ? $cat->name : get_bloginfo( 'name' ) )
		);
	},
	10,
	3
);

/*
 * ---------------------------------------------------------------------------
 * News: Startseite (feste Anzahl) und eigene News-Seite (alle Beiträge)
 * ---------------------------------------------------------------------------
 * Die Abfragen werden über ihre queryId erkannt – die bleibt erhalten, auch wenn
 * jemand die Startseite im Website-Editor anpasst und speichert.
 */
define( 'SPVGG_QUERY_FRONT', 61 );
define( 'SPVGG_QUERY_NEWS', 62 );

/**
 * Markup einer News-Karte (für alle Beitrags-Raster gleich).
 *
 * @return string Block-Markup für das Innere von core/post-template.
 */
function spvgg_post_card() {
	return '<!-- wp:group {"className":"is-style-spvgg-card","style":{"spacing":{"blockGap":"0","padding":{"bottom":"var:preset|spacing|40"}}},"layout":{"type":"default"}} -->
		<div class="wp-block-group is-style-spvgg-card" style="padding-bottom:var(--wp--preset--spacing--40)">
			<!-- wp:post-featured-image {"isLink":true,"aspectRatio":"16/10","className":"spvgg-card-image"} /-->
			<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|30","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"blockGap":"0.6rem"}},"layout":{"type":"default"}} -->
			<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--30);padding-right:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)">
				<!-- wp:group {"className":"spvgg-card-meta","style":{"spacing":{"blockGap":"0.75rem"}},"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} -->
				<div class="wp-block-group spvgg-card-meta">
					<!-- wp:post-terms {"term":"category","className":"spvgg-badge"} /-->
					<!-- wp:post-date {"format":"j. F Y"} /-->
				</div>
				<!-- /wp:group -->
				<!-- wp:post-title {"level":3,"isLink":true,"fontSize":"large"} /-->
				<!-- wp:post-excerpt {"moreText":"","excerptLength":22,"fontSize":"small"} /-->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:group -->';
}

/**
 * Anzahl der Beiträge auf der Startseite (Einstellungen → Lesen).
 */
function spvgg_front_posts() {
	return max( 1, min( 24, (int) get_option( 'spvgg_front_posts', 6 ) ) );
}

/**
 * URL der News-Seite: eingestellte Seite → WordPress-Beitragsseite → Startseite.
 */
function spvgg_news_url() {
	$id = (int) get_option( 'spvgg_news_page' );
	if ( $id && 'publish' === get_post_status( $id ) ) {
		return get_permalink( $id );
	}
	$posts_page = (int) get_option( 'page_for_posts' );
	return $posts_page ? get_permalink( $posts_page ) : home_url( '/' );
}

// Anzahl pro Abfrage durchsetzen (greift auch für die Seitennavigation).
add_filter(
	'query_loop_block_query_vars',
	function ( $query, $block ) {
		$id = (int) ( $block->context['queryId'] ?? 0 );
		if ( SPVGG_QUERY_FRONT === $id ) {
			$query['posts_per_page'] = spvgg_front_posts();
		} elseif ( SPVGG_QUERY_NEWS === $id ) {
			$query['posts_per_page'] = (int) get_option( 'posts_per_page', 10 );
		}
		return $query;
	},
	10,
	2
);

// Button „Alle News“ zeigt immer auf die aktuell eingestellte News-Seite.
add_filter(
	'render_block_core/button',
	function ( $html, $block ) {
		if ( false === strpos( $block['attrs']['className'] ?? '', 'spvgg-news-link' ) ) {
			return $html;
		}
		$tags = new WP_HTML_Tag_Processor( $html );
		if ( $tags->next_tag( 'a' ) ) {
			$tags->set_attribute( 'href', spvgg_news_url() );
		}
		return $tags->get_updated_html();
	},
	10,
	2
);

// Einstellungen → Lesen: Anzahl auf der Startseite und News-Seite.
add_action(
	'admin_init',
	function () {
		register_setting(
			'reading',
			'spvgg_front_posts',
			array(
				'type'              => 'integer',
				'default'           => 6,
				'sanitize_callback' => function ( $value ) {
					return max( 1, min( 24, absint( $value ) ) );
				},
			)
		);
		register_setting(
			'reading',
			'spvgg_news_page',
			array(
				'type'              => 'integer',
				'sanitize_callback' => 'absint',
			)
		);

		add_settings_field(
			'spvgg_front_posts',
			__( 'Beiträge auf der Startseite', 'spvgg' ),
			function () {
				printf(
					'<input name="spvgg_front_posts" id="spvgg_front_posts" type="number" min="1" max="24" step="1" value="%d" class="small-text"> %s<p class="description">%s</p>',
					(int) spvgg_front_posts(),
					esc_html__( 'Beiträge', 'spvgg' ),
					esc_html__( 'So viele aktuelle Beiträge zeigt die Startseite im Bereich „SpVgg News“.', 'spvgg' )
				);
			},
			'reading',
			'default',
			array( 'label_for' => 'spvgg_front_posts' )
		);
		add_settings_field(
			'spvgg_news_page',
			__( 'News-Seite', 'spvgg' ),
			function () {
				wp_dropdown_pages(
					array(
						'name'              => 'spvgg_news_page',
						'id'                => 'spvgg_news_page',
						'selected'          => (int) get_option( 'spvgg_news_page' ),
						'show_option_none'  => esc_html__( '— Auswählen —', 'spvgg' ),
						'option_none_value' => 0,
					)
				);
				echo '<p class="description">' . esc_html__( 'Ziel des Buttons „Alle News“. Die Seite sollte die Vorlage „Alle News“ verwenden.', 'spvgg' ) . '</p>';
			},
			'reading',
			'default',
			array( 'label_for' => 'spvgg_news_page' )
		);
	}
);

// Beim Aktivieren: News-Seite anlegen, falls noch keine eingestellt bzw. vorhanden ist.
add_action(
	'after_switch_theme',
	function () {
		$id = (int) get_option( 'spvgg_news_page' );
		if ( $id && get_post( $id ) ) {
			return;
		}
		$existing = get_posts(
			array(
				'post_type'   => 'page',
				'post_status' => 'any',
				'meta_key'    => '_wp_page_template', // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'  => 'page-news', // phpcs:ignore WordPress.DB.SlowDBQuery
				'numberposts' => 1,
				'fields'      => 'ids',
			)
		);
		if ( $existing ) {
			update_option( 'spvgg_news_page', (int) $existing[0] );
			return;
		}
		$id = wp_insert_post(
			array(
				'post_type'     => 'page',
				'post_status'   => 'publish',
				'post_title'    => 'News',
				'post_name'     => 'news',
				'post_content'  => '',
				'page_template' => 'page-news',
			)
		);
		if ( $id && ! is_wp_error( $id ) ) {
			update_option( 'spvgg_news_page', (int) $id );
		}
	}
);

/*
 * ---------------------------------------------------------------------------
 * Titel-Band (News, Kategorien, Suche, Beiträge, Seiten): Mini-Hero mit
 * Ausschnitt des Hero-Fotos. Die Muster patterns/title-band-*.php rufen das auf.
 * ---------------------------------------------------------------------------
 */

/**
 * Cover-Block mit Hero-Ausschnitt um den übergebenen Inhalt.
 *
 * @param string $inner Block-Markup für Zeile über dem Titel, Titel usw.
 * @return string Block-Markup.
 */
function spvgg_title_band( $inner ) {
	$url  = esc_url( get_theme_file_uri( 'assets/images/hero.jpg' ) );
	$grad = 'linear-gradient(180deg,rgba(11,11,11,0.2) 0%,rgba(11,11,11,0.88) 100%)';
	return '<!-- wp:cover {"url":"' . $url . '","dimRatio":100,"customGradient":"' . $grad . '","focalPoint":{"x":0.62,"y":0.22},"minHeight":340,"contentPosition":"bottom left","isDark":true,"align":"full","className":"spvgg-title-band","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"},"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-cover alignfull is-dark has-custom-content-position is-position-bottom-left spvgg-title-band" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);min-height:340px"><img class="wp-block-cover__image-background" alt="" src="' . $url . '" style="object-position:62% 22%" data-object-fit="cover" data-object-position="62% 22%"/><span aria-hidden="true" class="wp-block-cover__background has-background-dim-100 has-background-dim wp-block-cover__gradient-background has-background-gradient" style="background:' . $grad . '"></span><div class="wp-block-cover__inner-container">
	<!-- wp:group {"align":"wide","className":"spvgg-title-band__content","layout":{"type":"default"}} -->
	<div class="wp-block-group alignwide spvgg-title-band__content">
' . $inner . '
	</div>
	<!-- /wp:group -->
</div></div>
<!-- /wp:cover -->';
}

/**
 * Gelbe Zeile über dem Titel (wie „Seit 1948 · …“ im Hero).
 *
 * @param string $text Text der Zeile.
 * @return string Block-Markup.
 */
function spvgg_title_kicker( $text ) {
	return '<!-- wp:paragraph {"className":"spvgg-kicker","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.25em","fontWeight":"700"}},"textColor":"gelb","fontSize":"small"} -->
		<p class="spvgg-kicker has-gelb-color has-text-color has-small-font-size" style="font-weight:700;letter-spacing:0.25em;text-transform:uppercase">' . esc_html( $text ) . '</p>
		<!-- /wp:paragraph -->';
}

/*
 * ---------------------------------------------------------------------------
 * Abteilungsseiten (Vorlage „Abteilung“): Kacheln der Unterseiten + News der Abteilung
 * ---------------------------------------------------------------------------
 * Kacheln: alle veröffentlichten Unterseiten der aktuellen Seite (Reihenfolge = „Reihenfolge“
 * in den Seiten-Attributen). News: Kategorie aus dem Feld „Abteilung“ in der Seitenleiste
 * des Editors – ohne Auswahl die Kategorie mit gleichem Titelform (Slug) wie die Seite.
 */
define( 'SPVGG_QUERY_DEPT_PAGES', 63 );
define( 'SPVGG_QUERY_DEPT_NEWS', 64 );

/**
 * Kategorie einer Abteilungsseite.
 *
 * @param int $page_id Seite (Standard: aktuelle Seite).
 * @return WP_Term|null
 */
function spvgg_department_category( $page_id = 0 ) {
	$page_id = $page_id ? $page_id : get_queried_object_id();
	if ( ! $page_id ) {
		return null;
	}
	$chosen = (int) get_post_meta( $page_id, 'spvgg_category', true );
	if ( $chosen ) {
		$term = get_term( $chosen, 'category' );
		if ( $term instanceof WP_Term ) {
			return $term;
		}
	}
	$term = get_term_by( 'slug', get_post_field( 'post_name', $page_id ), 'category' );
	return $term instanceof WP_Term ? $term : null;
}

/**
 * Hat die aktuelle Seite veröffentlichte Unterseiten?
 */
function spvgg_department_has_children() {
	$id = get_queried_object_id();
	return $id && get_pages(
		array(
			'parent'      => $id,
			'number'      => 1,
			'post_status' => 'publish',
		)
	);
}

add_filter(
	'query_loop_block_query_vars',
	function ( $query, $block ) {
		$id = (int) ( $block->context['queryId'] ?? 0 );
		if ( SPVGG_QUERY_DEPT_PAGES === $id ) {
			$query['post_type']      = 'page';
			$query['post_parent']    = get_queried_object_id();
			$query['orderby']        = array(
				'menu_order' => 'ASC',
				'title'      => 'ASC',
			);
			$query['posts_per_page'] = 50;
		} elseif ( SPVGG_QUERY_DEPT_NEWS === $id ) {
			$term                    = spvgg_department_category();
			$query['posts_per_page'] = spvgg_front_posts();
			if ( $term ) {
				$query['cat'] = $term->term_id;
			} else {
				$query['post__in'] = array( 0 );
			}
		}
		return $query;
	},
	10,
	2
);

// Bereiche ohne Inhalt ausblenden; Button „Alle News“ auf die Kategorie der Abteilung zeigen lassen.
add_filter(
	'render_block_core/group',
	function ( $html, $block ) {
		$class = $block['attrs']['className'] ?? '';
		if ( false !== strpos( $class, 'spvgg-dept-tiles' ) && ! spvgg_department_has_children() ) {
			return '';
		}
		if ( false !== strpos( $class, 'spvgg-dept-news' ) && ! spvgg_department_category() ) {
			return '';
		}
		return $html;
	},
	10,
	2
);
add_filter(
	'render_block_core/button',
	function ( $html, $block ) {
		if ( false === strpos( $block['attrs']['className'] ?? '', 'spvgg-dept-news-link' ) ) {
			return $html;
		}
		$term = spvgg_department_category();
		if ( ! $term ) {
			return '';
		}
		$tags = new WP_HTML_Tag_Processor( $html );
		if ( $tags->next_tag( 'a' ) ) {
			$tags->set_attribute( 'href', get_term_link( $term ) );
		}
		return $tags->get_updated_html();
	},
	10,
	2
);

// Feld „Abteilung“ in der Seitenleiste des Seiten-Editors: Kategorie + Weiterleitung.
add_action(
	'init',
	function () {
		register_post_meta(
			'page',
			'spvgg_category',
			array(
				'type'              => 'integer',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'absint',
				'auth_callback'     => function () {
					return current_user_can( 'edit_pages' );
				},
			)
		);
		register_post_meta(
			'page',
			'spvgg_redirect',
			array(
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'esc_url_raw',
				'auth_callback'     => function () {
					return current_user_can( 'edit_pages' );
				},
			)
		);
	}
);

add_action(
	'add_meta_boxes_page',
	function () {
		add_meta_box(
			'spvgg-department',
			__( 'Abteilung', 'spvgg' ),
			function ( $post ) {
				wp_nonce_field( 'spvgg_department', 'spvgg_department_nonce' );
				echo '<p><label for="spvgg_category"><strong>' . esc_html__( 'News-Kategorie', 'spvgg' ) . '</strong></label></p>';
				wp_dropdown_categories(
					array(
						'name'              => 'spvgg_category',
						'id'                => 'spvgg_category',
						'selected'          => (int) get_post_meta( $post->ID, 'spvgg_category', true ),
						'show_option_none'  => esc_html__( 'Automatisch (gleicher Name)', 'spvgg' ),
						'option_none_value' => 0,
						'hide_empty'        => false,
						'hierarchical'      => true,
					)
				);
				echo '<p class="description">' . esc_html__( 'Nur für die Vorlage „Abteilung“: welche News unten auf der Seite erscheinen.', 'spvgg' ) . '</p>';
				printf(
					'<p><label for="spvgg_redirect"><strong>%1$s</strong></label><input type="url" class="widefat" id="spvgg_redirect" name="spvgg_redirect" value="%2$s" placeholder="https://…"></p><p class="description">%3$s</p>',
					esc_html__( 'Weiterleitung', 'spvgg' ),
					esc_attr( get_post_meta( $post->ID, 'spvgg_redirect', true ) ),
					esc_html__( 'Optional: Diese Seite leitet auf eine externe Adresse weiter (z. B. Jugend beim 1. FC Lechfeld). Ihre Kachel bleibt in der Abteilung sichtbar.', 'spvgg' )
				);
			},
			'page',
			'side'
		);
	}
);

add_action(
	'save_post_page',
	function ( $post_id ) {
		if ( ! isset( $_POST['spvgg_department_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['spvgg_department_nonce'] ), 'spvgg_department' ) ) {
			return;
		}
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_page', $post_id ) ) {
			return;
		}
		$cat = isset( $_POST['spvgg_category'] ) ? absint( $_POST['spvgg_category'] ) : 0;
		$url = isset( $_POST['spvgg_redirect'] ) ? esc_url_raw( wp_unslash( $_POST['spvgg_redirect'] ) ) : '';
		$cat ? update_post_meta( $post_id, 'spvgg_category', $cat ) : delete_post_meta( $post_id, 'spvgg_category' );
		$url ? update_post_meta( $post_id, 'spvgg_redirect', $url ) : delete_post_meta( $post_id, 'spvgg_redirect' );
	}
);

// Weiterleitung ausführen.
add_action(
	'template_redirect',
	function () {
		if ( ! is_page() ) {
			return;
		}
		$url = get_post_meta( get_queried_object_id(), 'spvgg_redirect', true );
		if ( $url ) {
			wp_redirect( $url, 302, 'SpVgg' ); // phpcs:ignore WordPress.Security.SafeRedirect -- bewusst externe Ziele, nur von Redakteuren gesetzt
			exit;
		}
	}
);

// Kacheln mit Weiterleitung als externen Link kennzeichnen (Pfeil-Symbol per CSS).
add_filter(
	'render_block_core/post-title',
	function ( $html, $block, $instance ) {
		if ( false === strpos( $block['attrs']['className'] ?? '', 'spvgg-dept-tile__title' ) ) {
			return $html;
		}
		$post_id = $instance->context['postId'] ?? 0;
		if ( $post_id && get_post_meta( $post_id, 'spvgg_redirect', true ) ) {
			$tags = new WP_HTML_Tag_Processor( $html );
			if ( $tags->next_tag() ) {
				$tags->add_class( 'is-external' );
			}
			return $tags->get_updated_html();
		}
		return $html;
	},
	10,
	3
);

// Block-Editor: Änderungen im Feld „Abteilung“ als ungespeicherte Änderung melden, damit „Speichern“ greift.
add_action(
	'enqueue_block_editor_assets',
	function () {
		if ( 'page' !== get_current_screen()->post_type ) {
			return;
		}
		wp_enqueue_script( 'spvgg-department-box', get_theme_file_uri( 'assets/js/department-box.js' ), array( 'wp-data', 'wp-editor' ), SPVGG_VERSION, true );
	}
);
