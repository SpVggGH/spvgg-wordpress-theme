/**
 * Abteilungsseiten: Kachel-Leiste wie die Slider auf bvb.de.
 * Kopfzeile mit Anzahl und Pfeilen oben rechts, Fortschrittsbalken darunter.
 * Beides erscheint nur, wenn mehr Kacheln da sind, als in die Breite passen (Klasse has-overflow).
 */
( function () {
	function el( tag, className, attrs ) {
		var node = document.createElement( tag );
		node.className = className;
		Object.keys( attrs || {} ).forEach( function ( key ) {
			node.setAttribute( key, attrs[ key ] );
		} );
		return node;
	}

	function setup( list ) {
		var wrap = list.parentElement;
		var count = list.children.length;

		var head = el( 'div', 'spvgg-dept-tiles__head' );
		var label = el( 'p', 'spvgg-dept-tiles__count' );
		label.textContent = count + ( 1 === count ? ' Bereich' : ' Bereiche' );
		var arrows = el( 'div', 'spvgg-dept-tiles__arrows' );
		var prev = el( 'button', 'spvgg-dept-tiles__arrow spvgg-dept-tiles__arrow--prev', { type: 'button', 'aria-label': 'Vorherige Kacheln' } );
		var next = el( 'button', 'spvgg-dept-tiles__arrow spvgg-dept-tiles__arrow--next', { type: 'button', 'aria-label': 'Weitere Kacheln' } );
		arrows.appendChild( prev );
		arrows.appendChild( next );
		head.appendChild( label );
		head.appendChild( arrows );
		wrap.insertBefore( head, list );

		var progress = el( 'div', 'spvgg-dept-tiles__progress', { 'aria-hidden': 'true' } );
		progress.appendChild( document.createElement( 'span' ) );
		wrap.appendChild( progress );

		function step( dir ) {
			list.scrollBy( { left: dir * list.clientWidth * 0.8 } );
		}
		prev.addEventListener( 'click', function () {
			step( -1 );
		} );
		next.addEventListener( 'click', function () {
			step( 1 );
		} );

		// Scroll-Ereignisse kommen ohnehin höchstens einmal pro Frame – direkt aktualisieren.
		function update() {
			var max = list.scrollWidth - list.clientWidth;
			var overflow = max > 2;
			wrap.classList.toggle( 'has-overflow', overflow );
			if ( ! overflow ) {
				return;
			}
			prev.disabled = list.scrollLeft <= 2;
			next.disabled = list.scrollLeft >= max - 2;
			// Balken: Breite = sichtbarer Anteil, Position = Scrollfortschritt.
			var visible = list.clientWidth / list.scrollWidth;
			progress.style.setProperty( '--spvgg-progress-w', ( visible * 100 ) + '%' );
			progress.style.setProperty( '--spvgg-progress-x', ( ( list.scrollLeft / max ) * ( 1 / visible - 1 ) * 100 ) + '%' );
		}
		list.addEventListener( 'scroll', update, { passive: true } );
		if ( 'ResizeObserver' in window ) {
			new ResizeObserver( update ).observe( list );
		} else {
			window.addEventListener( 'resize', update );
		}
		update();
	}

	function init() {
		document.querySelectorAll( '.spvgg-dept-tiles__grid' ).forEach( setup );
	}
	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
} )();
