/**
 * Kategorie-Bild: Auswahl über die Mediathek im Kategorie-Formular.
 */
( function ( $ ) {
	var frame;

	$( document ).on( 'click', '.spvgg-cat-image__pick', function ( event ) {
		event.preventDefault();
		var box = $( this ).closest( '.spvgg-cat-image' );

		frame = wp.media( {
			title: 'Kategorie-Bild wählen',
			button: { text: 'Bild übernehmen' },
			library: { type: 'image' },
			multiple: false,
		} );
		frame.on( 'select', function () {
			var image = frame.state().get( 'selection' ).first().toJSON();
			var url = ( image.sizes && image.sizes.medium ? image.sizes.medium : image ).url;
			box.find( 'input[type=hidden]' ).val( image.id );
			box.find( '.spvgg-cat-image__preview' ).html(
				$( '<img>', { src: url, alt: '', css: { maxWidth: '300px', height: 'auto', display: 'block', marginBottom: '8px' } } )
			);
			box.find( '.spvgg-cat-image__remove' ).prop( 'hidden', false );
		} );
		frame.open();
	} );

	$( document ).on( 'click', '.spvgg-cat-image__remove', function ( event ) {
		event.preventDefault();
		var box = $( this ).closest( '.spvgg-cat-image' );
		box.find( 'input[type=hidden]' ).val( '' );
		box.find( '.spvgg-cat-image__preview' ).empty();
		$( this ).prop( 'hidden', true );
	} );

	// Nach „Neue Kategorie hinzufügen“ (AJAX) das Feld leeren.
	$( document ).ajaxSuccess( function ( e, xhr, settings ) {
		if ( settings.data && settings.data.indexOf( 'action=add-tag' ) !== -1 ) {
			$( '#addtag .spvgg-cat-image__remove' ).trigger( 'click' );
		}
	} );
} )( jQuery );
