/**
 * Spiele (BFV): Umschalter „Nächste Spiele“ / „Ergebnisse“ (Tabs mit Pfeiltasten-Bedienung)
 * und eine immer sichtbare Scrollbar unter der Karten-Leiste (die native blendet macOS aus).
 */
( function () {
	function scrollbar( panel ) {
		var track = document.createElement( 'div' );
		var thumb = document.createElement( 'span' );
		track.className = 'spvgg-matches__scrollbar';
		track.setAttribute( 'aria-hidden', 'true' ); // Bedienung per Tastatur/Wischen bleibt an der Leiste selbst
		track.appendChild( thumb );
		panel.parentNode.insertBefore( track, panel.nextSibling );

		function update() {
			var max = panel.scrollWidth - panel.clientWidth;
			track.hidden = panel.hidden || max <= 2;
			if ( track.hidden ) {
				return;
			}
			// Balken: Breite = sichtbarer Anteil, Position = Scrollfortschritt (wie bei den Abteilungs-Kacheln).
			var visible = panel.clientWidth / panel.scrollWidth;
			thumb.style.width = visible * 100 + '%';
			thumb.style.transform = 'translateX(' + ( panel.scrollLeft / max ) * ( 1 / visible - 1 ) * 100 + '%)';
		}

		// Ziehen am Balken; Einrasten der Karten währenddessen aus, sonst springt die Leiste.
		var startX = 0;
		var startScroll = 0;
		thumb.addEventListener( 'pointerdown', function ( event ) {
			startX = event.clientX;
			startScroll = panel.scrollLeft;
			thumb.setPointerCapture( event.pointerId );
			track.classList.add( 'is-dragging' );
			panel.style.scrollSnapType = 'none';
			event.preventDefault();
			event.stopPropagation();
		} );
		thumb.addEventListener( 'pointermove', function ( event ) {
			if ( track.classList.contains( 'is-dragging' ) ) {
				panel.scrollLeft = startScroll + ( event.clientX - startX ) * ( panel.scrollWidth / track.clientWidth );
			}
		} );
		function endDrag() {
			track.classList.remove( 'is-dragging' );
			panel.style.scrollSnapType = '';
		}
		thumb.addEventListener( 'pointerup', endDrag );
		thumb.addEventListener( 'pointercancel', endDrag );

		// Klick auf die Spur: dorthin scrollen.
		track.addEventListener( 'pointerdown', function ( event ) {
			var rect = track.getBoundingClientRect();
			var ratio = ( event.clientX - rect.left ) / rect.width;
			panel.scrollTo( { left: ratio * panel.scrollWidth - panel.clientWidth / 2, behavior: 'smooth' } );
		} );

		panel.addEventListener( 'scroll', update, { passive: true } );
		if ( 'ResizeObserver' in window ) {
			new ResizeObserver( update ).observe( panel );
		} else {
			window.addEventListener( 'resize', update );
		}
		update();
		return update;
	}

	function setup( root ) {
		var tabs = Array.prototype.slice.call( root.querySelectorAll( '[role="tab"]' ) );
		var updates = Array.prototype.map.call( root.querySelectorAll( '.spvgg-matches__panel' ), scrollbar );

		function select( tab ) {
			tabs.forEach( function ( other ) {
				var active = other === tab;
				other.setAttribute( 'aria-selected', active ? 'true' : 'false' );
				other.tabIndex = active ? 0 : -1;
				document.getElementById( other.getAttribute( 'aria-controls' ) ).hidden = ! active;
			} );
			updates.forEach( function ( update ) {
				update();
			} );
		}

		tabs.forEach( function ( tab, i ) {
			tab.addEventListener( 'click', function () {
				select( tab );
			} );
			tab.addEventListener( 'keydown', function ( event ) {
				var step = { ArrowRight: 1, ArrowLeft: -1 }[ event.key ];
				if ( step ) {
					var next = tabs[ ( i + step + tabs.length ) % tabs.length ];
					select( next );
					next.focus();
					event.preventDefault();
				}
			} );
		} );
	}

	function init() {
		document.querySelectorAll( '.spvgg-matches' ).forEach( setup );
	}
	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
} )();
