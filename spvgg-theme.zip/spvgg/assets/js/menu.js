/**
 * Vollbild-Menü im BVB-Stil.
 *
 * - Der Burger öffnet UND schließt (wird per CSS zum X); der Core-Schließen-Knopf ist ausgeblendet.
 * - Das Panel startet direkt unter dem Header (Höhe wird beim Öffnen gemessen).
 * - Untermenüs klappen per Klick auf, immer nur eins offen.
 * - Such-Panel wie auf bvb.de: Lupe öffnet, „Abbrechen“/Escape/Klick daneben schließt;
 *   Menü und Suche schließen sich gegenseitig.
 *
 * Läuft in der Capture-Phase vor dem Core-Navigationsskript, damit dessen
 * eigenes Hover/Klick-Verhalten im Overlay nicht dazwischenfunkt.
 */
( function () {
	var OPEN = 'spvgg-open';
	var root = document.documentElement;
	var lastClosed = 0;

	function container() {
		return document.querySelector( '.spvgg-header__nav .wp-block-navigation__responsive-container' );
	}

	// Panels (Menü, Suche) starten direkt unter dem Header – Unterkante beim Öffnen messen.
	function measureHeader( el ) {
		var header = el.closest( '.spvgg-header' );
		if ( header ) {
			root.style.setProperty( '--spvgg-menu-top', Math.max( 0, header.getBoundingClientRect().bottom ) + 'px' );
		}
	}

	function panel() {
		return document.getElementById( 'spvgg-search-panel' );
	}

	function toggleButton() {
		return document.querySelector( '.spvgg-search-toggle' );
	}

	function isSearchOpen() {
		var p = panel();
		return !! p && p.classList.contains( 'is-open' );
	}

	function openSearch() {
		var p = panel();
		var t = toggleButton();
		if ( ! p ) {
			return;
		}
		measureHeader( t || p );
		p.inert = false;
		p.classList.add( 'is-open' );
		root.classList.add( 'spvgg-search-open' );
		if ( t ) {
			t.setAttribute( 'aria-expanded', 'true' );
			t.setAttribute( 'aria-label', 'Suche schließen' );
		}
		// Direkt im Klick fokussieren, damit auf dem Handy die Tastatur aufgeht.
		var input = p.querySelector( 'input[type="search"]' );
		if ( input ) {
			input.focus( { preventScroll: true } );
		}
	}

	function closeSearch( returnFocus ) {
		var p = panel();
		var t = toggleButton();
		if ( ! isSearchOpen() ) {
			return;
		}
		p.classList.remove( 'is-open' );
		p.inert = true;
		root.classList.remove( 'spvgg-search-open' );
		if ( t ) {
			t.setAttribute( 'aria-expanded', 'false' );
			t.setAttribute( 'aria-label', 'Suche öffnen' );
			if ( returnFocus ) {
				t.focus( { preventScroll: true } );
			}
		}
	}

	function closeMenu() {
		var c = container();
		var close = c && c.querySelector( '.wp-block-navigation__responsive-container-close' );
		if ( close && c.classList.contains( 'is-menu-open' ) ) {
			close.click();
		}
	}

	function setSubmenu( item, open ) {
		item.classList.toggle( OPEN, open );
		item.querySelectorAll( ':scope > [aria-expanded]' ).forEach( function ( el ) {
			el.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
		} );
	}

	// Öffnen/Schließen-Zustand an <html> spiegeln (für das Burger-X) und Untermenüs nach dem Schließen zurücksetzen.
	function watch() {
		var c = container();
		if ( ! c ) {
			return;
		}
		new MutationObserver( function () {
			var isOpen = c.classList.contains( 'is-menu-open' );
			if ( ! isOpen && root.classList.contains( 'spvgg-menu-open' ) ) {
				lastClosed = Date.now();
				setTimeout( function () {
					c.querySelectorAll( '.' + OPEN ).forEach( function ( item ) {
						setSubmenu( item, false );
					} );
				}, 500 );
			}
			root.classList.toggle( 'spvgg-menu-open', isOpen );
		} ).observe( c, { attributes: true, attributeFilter: [ 'class' ] } );
	}
	function init() {
		watch();
		watchScroll();
		if ( panel() ) {
			panel().inert = true;
		}
	}
	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}

	/*
	 * Header-Variante „Logo ragt hinein“: Logo nach dem Scrollen einziehen.
	 * Zwei unsichtbare Markierungen statt Scroll-Event: einziehen, sobald die 60px-Marke
	 * oben verschwindet, wieder groß erst, wenn die 20px-Marke zurückkommt. Der Puffer
	 * dazwischen verhindert Hin- und Herspringen an der Grenze (z. B. Trackpad-Nachschwingen).
	 */
	function watchScroll() {
		if ( ! ( 'IntersectionObserver' in window ) ) {
			return;
		}
		function marker( y ) {
			var m = document.createElement( 'div' );
			m.setAttribute( 'aria-hidden', 'true' );
			m.style.cssText = 'position:absolute;left:0;top:' + y + 'px;width:1px;height:1px;pointer-events:none;visibility:hidden;';
			document.body.appendChild( m );
			return m;
		}
		var shrinkAt = marker( 60 );
		var growAt = marker( 20 );
		var observer = new IntersectionObserver( function ( entries ) {
			entries.forEach( function ( entry ) {
				var above = entry.boundingClientRect.top < 0;
				if ( entry.target === shrinkAt && ! entry.isIntersecting && above ) {
					root.classList.add( 'spvgg-scrolled' );
				} else if ( entry.target === growAt && entry.isIntersecting ) {
					root.classList.remove( 'spvgg-scrolled' );
				}
			} );
		} );
		observer.observe( shrinkAt );
		observer.observe( growAt );
	}

	document.addEventListener( 'keydown', function ( event ) {
		if ( 'Escape' === event.key && isSearchOpen() ) {
			closeSearch( true );
		}
	} );

	document.addEventListener(
		'click',
		function ( event ) {
			var burger = event.target.closest( '.spvgg-header__nav .wp-block-navigation__responsive-container-open' );
			if ( burger ) {
				var c = container();
				// Klick auf das X: Der Core hat beim Fokuswechsel evtl. schon geschlossen – dann nicht wieder öffnen.
				if ( ( c && c.classList.contains( 'is-menu-open' ) ) || Date.now() - lastClosed < 400 ) {
					event.preventDefault();
					event.stopPropagation();
					var close = c && c.querySelector( '.wp-block-navigation__responsive-container-close' );
					if ( close && c.classList.contains( 'is-menu-open' ) ) {
						// Erst nach dem aktuellen Event schließen, sonst öffnet der Core-Handler am Burger direkt wieder.
						setTimeout( function () {
							close.click();
						}, 0 );
					}
					return;
				}
				closeSearch( false );
				measureHeader( burger );
				return;
			}

			// Lupe: Such-Panel öffnen bzw. wieder schließen.
			if ( event.target.closest( '.spvgg-search-toggle' ) ) {
				if ( isSearchOpen() ) {
					closeSearch( false );
				} else {
					setTimeout( closeMenu, 0 );
					openSearch();
				}
				return;
			}

			// „Abbrechen“ oder Klick auf den verschwommenen Bereich unter dem Panel (Desktop).
			if ( event.target.closest( '.spvgg-search-cancel' ) || event.target.classList.contains( 'spvgg-search-panel__slide' ) ) {
				closeSearch( true );
				return;
			}

			var trigger = event.target.closest(
				'.is-menu-open .has-child > .wp-block-navigation-item__content, .is-menu-open .has-child > .wp-block-navigation__submenu-icon'
			);
			if ( ! trigger ) {
				return;
			}
			event.preventDefault();
			event.stopPropagation();

			var item = trigger.parentElement;
			var willOpen = ! item.classList.contains( OPEN );
			Array.prototype.forEach.call( item.parentElement.children, function ( sibling ) {
				setSubmenu( sibling, false );
			} );
			if ( willOpen ) {
				setSubmenu( item, true );
			}
		},
		true
	);
} )();
