/**
 * Editor-Ansicht für den Block „Spiele (BFV)“: Vorschau vom Server, Einstellung der Startansicht.
 */
( function ( wp ) {
	var el = wp.element.createElement;
	var InspectorControls = wp.blockEditor.InspectorControls;
	var PanelBody = wp.components.PanelBody;
	var SelectControl = wp.components.SelectControl;
	var TextControl = wp.components.TextControl;

	wp.blocks.registerBlockType( 'spvgg/matches', {
		edit: function ( props ) {
			return el(
				'div',
				wp.blockEditor.useBlockProps(),
				el(
					InspectorControls,
					null,
					el(
						PanelBody,
						{ title: 'Spiele' },
						el( TextControl, {
							label: 'Überschrift',
							value: props.attributes.heading,
							onChange: function ( heading ) {
								props.setAttributes( { heading: heading } );
							},
						} ),
						el( SelectControl, {
							label: 'Zuerst anzeigen',
							value: props.attributes.view,
							options: [
								{ label: 'Nächste Spiele', value: 'next' },
								{ label: 'Ergebnisse', value: 'results' },
							],
							onChange: function ( view ) {
								props.setAttributes( { view: view } );
							},
						} ),
						el( 'p', null, el( 'a', { href: 'admin.php?page=spvgg-spielplan', target: '_blank' }, 'Mannschaften und Ergebnisse verwalten' ) )
					)
				),
				el( wp.serverSideRender, { block: 'spvgg/matches', attributes: props.attributes } )
			);
		},
		save: function () {
			return null;
		},
	} );
} )( window.wp );
