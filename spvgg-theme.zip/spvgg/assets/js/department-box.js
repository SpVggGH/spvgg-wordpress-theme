/**
 * Feld „Abteilung“ (klassische Meta-Box) mit dem Block-Editor verbinden: Eine Änderung
 * wird als Bearbeitung der Seite gemeldet – sonst bliebe „Speichern“ wirkungslos, wenn
 * nur dieses Feld geändert wurde. Gespeichert wird über die REST-Meta-Felder.
 */
( function ( wp ) {
	var fields = { spvgg_category: 'int', spvgg_redirect: 'string' };

	document.addEventListener( 'change', function ( event ) {
		var name = event.target && event.target.name;
		if ( ! fields[ name ] ) {
			return;
		}
		var value = 'int' === fields[ name ] ? parseInt( event.target.value, 10 ) || 0 : event.target.value.trim();
		var meta = {};
		meta[ name ] = value;
		wp.data.dispatch( 'core/editor' ).editPost( { meta: meta } );
	} );
} )( window.wp );
