<?php
// Demo-Inhalte für die lokale Playground-Instanz (nicht Teil des Themes).
require '/wordpress/wp-load.php';
require_once ABSPATH . 'wp-admin/includes/image.php';

update_option( 'blogname', 'SpVgg Lagerlechfeld-Graben e.V.' );
update_option( 'blogdescription', 'seit 1948' );
update_option( 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/' );
update_option( 'show_on_front', 'posts' );
switch_theme( 'spvgg' );

// Seiten
$page = function ( $title, $slug, $parent = 0 ) {
	return wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => $title, 'post_name' => $slug, 'post_parent' => $parent, 'post_content' => '<!-- wp:paragraph --><p>Platzhalterinhalt für „' . $title . '“.</p><!-- /wp:paragraph -->' ) );
};
$verein = $page( 'Verein', 'verein' );
$ids = array( 'vorstand' => $page( 'Vorstand', 'vorstand', $verein ), 'mitglied' => $page( 'Mitglied werden', 'mitglied-werden', $verein ), 'geschichte' => $page( 'Geschichte', 'geschichte-der-spvgg', $verein ), 'satzung' => $page( 'Satzung', 'satzung', $verein ) );
$abt = $page( 'Abteilungen', 'abteilungen' );
foreach ( array( 'Fußball', 'Gymnastik & Fitness', 'Tennis', 'Ski & Berg', 'Stockschießen', 'Tischtennis', 'Steeldart (Rabbits)' ) as $a ) {
	$ids[ $a ] = $page( $a, sanitize_title( $a ), $abt );
}
// Abteilungsseiten nutzen die Vorlage „Abteilung“; Fußball bekommt Mannschaften als Unterseiten.
foreach ( array( 'Fußball', 'Gymnastik & Fitness', 'Tennis', 'Ski & Berg', 'Stockschießen', 'Tischtennis', 'Steeldart (Rabbits)' ) as $a ) {
	update_post_meta( $ids[ $a ], '_wp_page_template', 'page-abteilung' );
}
foreach ( array( '1. Herren', '2. Herren', '3. Herren', 'Alte Herren (AH)', 'Jugend (1. FC Lechfeld)' ) as $order => $t ) {
	$team = $page( $t, sanitize_title( $t ), $ids['Fußball'] );
	wp_update_post( array( 'ID' => $team, 'menu_order' => $order ) );
}
update_post_meta( $team, 'spvgg_redirect', 'https://1fclechfeld.de/' ); // letzte = Jugend
// Weitere Unterseiten, damit die Kachel-Leiste blättert
foreach ( array( 'Damen', 'U23', 'Spielplan', 'Trainingszeiten', 'Schiedsrichter', 'Sportgelände', 'Förderverein' ) as $order => $t ) {
	$sub = $page( $t, sanitize_title( $t ), $ids['Fußball'] );
	wp_update_post( array( 'ID' => $sub, 'menu_order' => 10 + $order ) );
}
$ids['veranstaltungen'] = $page( 'Veranstaltungen', 'veranstaltungen' );
$ids['kontakt']         = $page( 'Kontakt', 'kontakte' );
$ids['sponsoring']      = $page( 'Sponsoring', 'sponsoring' );

// Block-Menü (wp_navigation) – so wird es auch im Website-Editor gepflegt.
$link = function ( $title, $url ) {
	return '<!-- wp:navigation-link ' . wp_json_encode( array( 'label' => $title, 'url' => $url ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_AMP ) . ' /-->';
};
$sub = function ( $title, $children ) {
	return '<!-- wp:navigation-submenu ' . wp_json_encode( array( 'label' => $title, 'url' => '#' ), JSON_UNESCAPED_UNICODE ) . ' -->' . implode( '', $children ) . '<!-- /wp:navigation-submenu -->';
};
$verein = array();
foreach ( array( 'Vorstand' => 'vorstand', 'Mitglied werden' => 'mitglied', 'Geschichte' => 'geschichte', 'Satzung' => 'satzung' ) as $t => $k ) {
	$verein[] = $link( $t, get_permalink( $ids[ $k ] ) );
}
$abteilungen = array();
foreach ( array( 'Fußball', 'Gymnastik & Fitness', 'Tennis', 'Ski & Berg', 'Stockschießen', 'Tischtennis', 'Steeldart (Rabbits)' ) as $t ) {
	$abteilungen[] = $link( $t, get_permalink( $ids[ $t ] ) );
}
wp_insert_post( array(
	'post_type'    => 'wp_navigation',
	'post_status'  => 'publish',
	'post_title'   => 'Hauptmenü',
	// wp_slash: wp_insert_post entfernt Backslashes, sonst wird aus \u0026 ein kaputtes „u0026“.
	'post_content' => wp_slash( $link( 'News', home_url( '/' ) ) . $sub( 'Verein', $verein ) . $sub( 'Abteilungen', $abteilungen )
		. $link( 'Veranstaltungen', get_permalink( $ids['veranstaltungen'] ) ) . $link( 'Kontakt', get_permalink( $ids['kontakt'] ) ) . $link( 'Sponsoring', get_permalink( $ids['sponsoring'] ) ) ),
) );

// Kategorien + Beiträge (Titel angelehnt an die aktuellen News)
$cat = function ( $n ) {
	$t = term_exists( $n, 'category' );
	return $t ? (int) $t['term_id'] : (int) wp_insert_term( $n, 'category' )['term_id'];
};
$posts = array(
	array( 'Digital unterwegs: Unsere eigenen Vereins-Apps und Kartenzahlung am Tresen', 'Allgemein', 1 ),
	array( 'Wochenrückblick – Saisonfinale 2026', 'Fußball', 2 ),
	array( 'Anmeldung Sonnenaufgangstour 25.10.2026', 'Ski und Berg', 0 ),
	array( 'Anmeldung zu den Ski- und Snowboardkursen 2027 gestartet!', 'Ski und Berg', 3 ),
	array( 'Heimturnier – 26. Ritter-Wanderpokal', 'Stockschießen', 4 ),
	array( 'Saisonstart im Tischtennis', 'Tischtennis', 0 ),
	array( 'Wochenrückblick', 'Fußball', 2 ),
	array( 'Anmeldung Wanderung Hoher Ifen', 'Ski und Berg', 3 ),
	array( 'Dart Saisonauftakt 2026/2027', 'Steeldart', 0 ),
	array( 'Ehrung für besondere Leistungen', 'Bekanntmachungen', 1 ),
);
$att = array();
foreach ( $posts as $i => $p ) {
	$id = wp_insert_post( array(
		'post_status'   => 'publish',
		'post_title'    => $p[0],
		'post_date'     => gmdate( 'Y-m-d H:i:s', strtotime( '2026-10-21' ) - $i * 4 * DAY_IN_SECONDS ),
		'post_category' => array( $cat( $p[1] ) ),
		'post_content'  => '<!-- wp:paragraph --><p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p><!-- /wp:paragraph -->',
	) );
	if ( $p[2] ) {
		if ( empty( $att[ $p[2] ] ) ) {
			$src  = __DIR__ . '/demo-images/demo-' . $p[2] . '.jpg';
			$up   = wp_upload_bits( basename( $src ), null, file_get_contents( $src ) );
			$aid  = wp_insert_attachment( array( 'post_mime_type' => 'image/jpeg', 'post_title' => 'Demo ' . $p[2] ), $up['file'] );
			wp_update_attachment_metadata( $aid, wp_generate_attachment_metadata( $aid, $up['file'] ) );
			$att[ $p[2] ] = $aid;
		}
		set_post_thumbnail( $id, $att[ $p[2] ] );
	}
}
update_post_meta( $ids['Ski & Berg'], 'spvgg_category', $cat( 'Ski und Berg' ) );
// Spielplan: echte iCal-Links des BFV (Saison 2026/27); dazu erfundene Demo-Ergebnisse (nur Demo).
update_option( 'timezone_string', 'Europe/Berlin' );
$bfv = 'https://service.bfv.de/rest/icsexport/Spielplan?id=00ES8GNJAC000008VV0AG08LVUPGND5I&staffel=';
update_option(
	'spvgg_bfv_teams',
	array(
		array( 'name' => '1. Mannschaft', 'ics' => $bfv . '0310VQLQFK000003VS5489BTVT51B5B5-G' ),
		array( 'name' => '2. Mannschaft', 'ics' => $bfv . '0310VPOA7C000008VS5489BTVT51B5B5-G' ),
		array( 'name' => '3. Mannschaft', 'ics' => $bfv . '0310VQ20B0000005VS5489BTVT51B5B5-G' ),
	)
);
$demo = function ( $team, $days, $home, $away, $league, $venue, $city, $score = '' ) {
	$start = strtotime( "-$days days 14:00" );
	return array_filter( array( 'team' => $team, 'start' => $start, 'end' => $start + 6300, 'home' => $home, 'away' => $away, 'comp' => 'Meisterschaften', 'league' => $league, 'venue' => $venue, 'city' => $city, 'score' => $score ) );
};
update_option(
	'spvgg_bfv_matches',
	array(
		'demo1a' => $demo( '1-mannschaft', 10, 'SpVgg Lagerlechfeld', 'Demo SV Musterstadt', 'KL Augsburg', 'Hans-Winkler-Sportanlage Hauptfeld', 'Graben', '3:1' ),
		'demo1b' => $demo( '1-mannschaft', 3, 'FC Demo-Beispiel 1920', 'SpVgg Lagerlechfeld', 'KL Augsburg', 'Demo-Sportpark', 'Augsburg', '2:2' ),
		'demo2a' => $demo( '2-mannschaft', 3, 'SpVgg Lagerlechfeld 2', '(SG1) TSV Demo/SV Probe 2', 'AK Augsburg', 'Hans-Winkler-Sportanlage Hauptfeld', 'Graben', '0:1' ),
		'demo3a' => $demo( '3-mannschaft', 5, 'TSV Demohausen', 'SpVgg Lagerlechfeld 3', 'BK Augsburg', 'Sportplatz Demohausen', 'Bobingen' ),
	),
	false
);
// Anstehende Spiele gleich live vom BFV holen (das Theme ist in diesem Aufruf noch nicht geladen).
require_once get_theme_root() . '/spvgg/inc/matches.php';
spvgg_bfv_refresh();
// Wappen und Spieltag stehen nur auf bfv.de-Seiten, die der Browser-Playground nicht abrufen darf –
// dafür ein Schnappschuss aus der lokalen Instanz (snapshot/).
$snapshot = json_decode( (string) file_get_contents( __DIR__ . '/snapshot/bfv-details.json' ), true );
$matches  = get_option( 'spvgg_bfv_matches', array() );
foreach ( (array) $snapshot as $uid => $details ) {
	if ( isset( $matches[ $uid ] ) && empty( $matches[ $uid ]['clubs'] ) ) {
		$matches[ $uid ] = array_merge( $matches[ $uid ], $details );
	}
}
update_option( 'spvgg_bfv_matches', $matches, false );
$crests = spvgg_bfv_crest_dir();
wp_mkdir_p( $crests['dir'] );
foreach ( glob( __DIR__ . '/snapshot/wappen/*.png' ) as $file ) {
	copy( $file, $crests['dir'] . '/' . basename( $file ) );
}
wp_delete_post( 1, true ); // „Hallo Welt“
flush_rewrite_rules();
echo "seeded\n";
