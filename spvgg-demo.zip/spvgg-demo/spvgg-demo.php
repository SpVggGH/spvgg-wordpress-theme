<?php
/**
 * Plugin Name: SpVgg Demo-Inhalte
 * Description: Nur für die Playground-Vorschau. Nicht aktivieren.
 */
